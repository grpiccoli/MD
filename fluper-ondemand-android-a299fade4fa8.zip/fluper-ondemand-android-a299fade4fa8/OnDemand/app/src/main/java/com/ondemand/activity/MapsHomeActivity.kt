package com.ondemand.activity

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Bundle
import android.support.design.widget.NavigationView
import android.support.v4.app.Fragment
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.app.ActionBarDrawerToggle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.text.Spannable
import android.text.SpannableString
import android.util.Log
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.RelativeLayout
import com.bumptech.glide.Glide
import com.ondemand.R
import com.ondemand.api.ApiClient
import com.ondemand.api.ApiInterface
import com.ondemand.api.Const
import com.ondemand.api.model.ApiMethods
import com.ondemand.api.model.CommonResp
import com.ondemand.customview.CFButton
import com.ondemand.customview.CustomTypefaceSpan
import com.ondemand.fragment.FindAndBookFragment
import com.ondemand.fragment.MapFragment
import com.ondemand.fragment.ServiceProviderFragment
import com.ondemand.fragment.WaitingRoomActivity
import com.ondemand.storage.PreferenceHelper
import com.ondemand.storage.PreferenceHelper.get
import com.ondemand.utils.Constants
import com.ondemand.utils.Utils
import de.hdodenhof.circleimageview.CircleImageView
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_maps_home.*
import kotlinx.android.synthetic.main.activity_profile_edit.*
import kotlinx.android.synthetic.main.content_maps_home.*

class MapsHomeActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener, View.OnClickListener {

    private lateinit var prefs: SharedPreferences
    var drawerToggle: ActionBarDrawerToggle? = null
    val service = ApiClient.client.create(ApiInterface::class.java)

    override fun onClick(v: View?) {
        when (v?.id) {

            R.id.btn_view_as_list -> {
                val fragment = supportFragmentManager.findFragmentById(R.id.container)
                if (fragment is MapFragment) {
                    replaceFragment(ServiceProviderFragment())
                    supportActionBar?.setTitle("Service Provider")
                    btn_view_as_list.visibility = View.GONE

                    drawerToggle?.isDrawerIndicatorEnabled = false
                    drawerToggle?.setHomeAsUpIndicator(R.drawable.back_black)
                } else {
                    initMapFragment()
                    supportActionBar?.setTitle("MD")
                    btn_view_as_list.text = "VIEW AS LIST"
                    drawerToggle?.isDrawerIndicatorEnabled = false
                    drawerToggle?.setHomeAsUpIndicator(R.drawable.ic_menu_black_24dp)
                }
            }

            R.id.edt_search_spec -> {
                openFindBookFrag()

            }

            R.id.profile_rl,
            R.id.imageView -> {
                startActivity(Intent(this, ProfileEditActivity::class.java))
            }

            R.id.close_menu -> {
                if (drawer_layout.isDrawerOpen(GravityCompat.START)) {
                    drawer_layout.closeDrawer(GravityCompat.START)

                }
            }
        }
    }

    private fun openFindBookFrag() {

        replaceFragment(FindAndBookFragment())
        supportActionBar?.setTitle("Find And Book")
        btn_view_as_list.visibility = View.GONE

        drawerToggle?.isDrawerIndicatorEnabled = false
        drawerToggle?.setHomeAsUpIndicator(R.drawable.back_black)
    }

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps_home)
        prefs = PreferenceHelper.customPrefs(applicationContext)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)

        setFontToMenuItem(navView);

        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )

        drawerToggle = toggle

        drawerLayout.addDrawerListener(toggle)
        toggle.setToolbarNavigationClickListener {
            var fragment = supportFragmentManager.findFragmentById(R.id.container)
            if (fragment is MapFragment) {
                drawerLayout.openDrawer(Gravity.START)
            } else {
                onBackPressed()
            }
        }
        toggle.syncState()

        navView.setNavigationItemSelectedListener(this)

        setListener()

        initMapFragment()

        getIntentActions()
    }

    private fun getIntentActions() {

        intent?.extras?.let {
            when (it.getInt(Constants.INTENT_KEY_ACTION)) {
                Constants.INTENT_VAL_CANC_APPNT -> {

                    val alertd = Utils.showDialog(this@MapsHomeActivity, R.layout.dialog_alert_appnt_conf_book)

                    alertd.setCancelable(false)
                    alertd.findViewById<CFButton>(R.id.btn_okay)?.setOnClickListener {
                        alertd.dismiss()
                    }

                }
                else -> {

                }
            }
        }

    }


    private fun setFontToMenuItem(navView: NavigationView) {
        val m: Menu = navView.menu
        val tf1 = Typeface.createFromAsset(assets, "fonts/AvenirLTStd-Roman.otf")

        for (i in 0 until m.size()) {
            val mi = m.getItem(i)

            val s = SpannableString(mi.title)
            s.setSpan(
                CustomTypefaceSpan("", tf1), 0, s.length,
                Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            mi.title = s
        }

    }

    private fun initMapFragment() {
        val mapFragment = MapFragment()
//        replaceFragment(MapFragment())
        if (mapFragment.isAdded) {

            mapFragment.childFragmentManager.beginTransaction().replace(R.id.container, mapFragment, null).commit()
        } else {
            replaceFragment(mapFragment)
        }

    }

    var imgView: CircleImageView? = null

    private fun setListener() {
//        ll_logout.setOnClickListener(this)
        btn_view_as_list.setOnClickListener(this)
        edt_search_spec.setOnClickListener(this)

        nav_view.getHeaderView(0)?.findViewById<RelativeLayout>(R.id.profile_rl)?.setOnClickListener(this)
        imgView = nav_view.getHeaderView(0)?.findViewById<CircleImageView>(R.id.imageView)
        imgView?.setOnClickListener(this)
        findViewById<ImageButton>(R.id.close_menu)?.setOnClickListener(this)

    }

    override fun onResume() {
        super.onResume()
        val prefs = PreferenceHelper.customPrefs(applicationContext)

        try {
            Glide.with(this)
                .load(ApiMethods.getProfileImageURL(this)).placeholder(R.drawable.place_holder)
                .error(R.drawable.place_holder)// Remote URL of image.
                .into(imgView as ImageView)
        } catch (E : UnsupportedOperationException){
            Log.e("Error", E.message)
        }
    }

    override fun onBackPressed() {

        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)

        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)

        } else {

            if (!(supportFragmentManager.findFragmentById(R.id.container) is MapFragment)) {
                initMapFragment()
                btn_view_as_list.visibility = View.VISIBLE

                supportActionBar?.setTitle("MD")
                ll_quick_filters.visibility = View.VISIBLE

                drawerToggle?.isDrawerIndicatorEnabled = true
                drawerToggle?.setHomeAsUpIndicator(R.drawable.ic_menu_black_24dp)

                return
            }

            super.onBackPressed()
        }

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.maps_home, menu)

        return true
    }

    fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction().replace(R.id.container, fragment, null).commit()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_need_help -> {
                startActivity(Intent(this@MapsHomeActivity, NeedHelpActivity::class.java))

                true
            }
            R.id.action_filter -> {

                startActivity(Intent(this@MapsHomeActivity, FiltersActivity::class.java))

                true
            }

            else -> super.onOptionsItemSelected(item)

        }

    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        // Handle navigation view item clicks here.
        when (item.itemId) {

            R.id.nav_my_bookings -> {
                // Handle the camera action
                startActivity(Intent(this@MapsHomeActivity, MyBookingActivity::class.java))

            }
            R.id.nav_my_fav_doc -> {
                startActivity(Intent(this@MapsHomeActivity, MyFavDoctorActivity::class.java))

            }
            R.id.nav_services -> {
                openFindBookFrag()

            }
            R.id.nav_waiting_room -> {
                startActivity(Intent(this@MapsHomeActivity, WaitingRoomActivity::class.java))

            }
            R.id.nav_my_payments -> {
                startActivity(Intent(this@MapsHomeActivity, MyPaymentActivity::class.java))

            }
            R.id.nav_notification -> {
                startActivity(Intent(this@MapsHomeActivity, NotificationActivity::class.java))

            }
            R.id.nav_setting -> {
                startActivity(Intent(this@MapsHomeActivity, SettingActivity::class.java))

            }
            R.id.nav_need_help -> {
                startActivity(Intent(this@MapsHomeActivity, NeedHelpActivity::class.java))

            }
            R.id.nav_logout -> {

                if (prefs[Const.ACCESSTOKEN_KEY, ""]!!.equals("")){
                    Utils.showToast(this, "Please login first!")

                    return false
                }
                logout()
//                val intent = Intent(this, SignInActivity::class.java)
//                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
//
//                startActivity(intent)
            }

        }

        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        drawerLayout.closeDrawer(GravityCompat.START)

        return true

    }

//    inline public fun <reified T : Activity> start() {
//        startActivity(Intent(this, javaClass<T>()))
//    }
//    start<MainActivity>()
//
//    fun changeActivity( mapsHomeActivity: Activity, reified ) {
//        startActivity(Intent(mapsHomeActivity, java))
//    }

    fun logout() {
        val prefs = PreferenceHelper.customPrefs(applicationContext)

        val ser = service.logout(
            prefs[Const.ACCESSTOKEN_KEY, ""]
        )

            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { onSuccessPasswordChange(it) },
                { onFailure(it) }
            )
    }

    private fun onFailure(it: Throwable?) {


    }

    private fun onSuccessPasswordChange(it: CommonResp?) {
        Utils.showToast(this, "Logout Successfully")
        PreferenceHelper.clearTempOTPVals(this)
        val intent = Intent(this, SignInActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK

        startActivity(intent)
        finish()

    }

}
