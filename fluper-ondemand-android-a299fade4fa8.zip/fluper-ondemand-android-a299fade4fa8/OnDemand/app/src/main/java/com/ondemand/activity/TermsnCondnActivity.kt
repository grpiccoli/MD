package com.ondemand.activity

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import com.ondemand.R
import com.ondemand.utils.Constants
import kotlinx.android.synthetic.main.toolbar.*

class TermsnCondnActivity : AppCompatActivity(), View.OnClickListener {

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.back_btn -> {
                onBackPressed()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_termsn_condn)

        setListener()

        getIntentAction()
    }

    private fun getIntentAction() {
        intent?.extras?.let {
            when(it.getInt(Constants.INTENT_OPEN_ACTION)){
                Constants.INTENT_VAL_OPEN_TERMSN -> {
                    updateUI("Terms & Condition")
                }
                Constants.INTENT_VAL_OPEN_PRIVCY_POL -> {
                    updateUI("Privacy Policy")

                }
                Constants.INTENT_VAL_OPEN_ABOUTUS -> {
                    updateUI("About Us")

                }

                Constants.INTENT_VAL_OPEN_NEEDHELP -> {
                    updateUI("Need Help")

                }
            }
        }
    }

    private fun updateUI(s: String) {
        toolbar_text.text = s
    }

    private fun setListener() {
        back_btn.setOnClickListener(this)
    }

}
