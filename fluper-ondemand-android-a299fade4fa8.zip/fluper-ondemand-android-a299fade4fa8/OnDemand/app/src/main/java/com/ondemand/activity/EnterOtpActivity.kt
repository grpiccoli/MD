package com.ondemand.activity

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import com.ondemand.R
import com.ondemand.api.ApiClient
import com.ondemand.api.ApiInterface
import com.ondemand.api.Const
import com.ondemand.api.model.ResponseOtp
import com.ondemand.storage.PreferenceHelper
import com.ondemand.utils.Utils
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_enter_otp.*
import kotlinx.android.synthetic.main.activity_enter_otp.back_btn
import com.ondemand.storage.PreferenceHelper.get
import com.ondemand.utils.Constants
import com.ondemand.utils.ErrorUtil


class EnterOtpActivity : AppCompatActivity(), View.OnClickListener {

    private var otpCode : String? = Const.OTP_BY_SMS

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.back_btn -> {
                onBackPressed()
            }

            R.id.btn_submit_otp -> {
                validateNCheck()
            }
        }
    }

    private fun validateNCheck() {
        var otp = pinview.value.toString()

        if (!otp.isEmpty() && otp.length ==6) {
            val service = ApiClient.client.create(ApiInterface::class.java)
            val prefs = PreferenceHelper.customPrefs(applicationContext)
            btn_submit_otp.isEnabled = false
            when (otpCode){

                Const.OTP_BY_CALL -> {
                    val ser = service.verifyOtp(
                        prefs[Const.T_MOBILE_KEY],
                        prefs[Const.T_COUNTRYCODE_KEY],
                        "",
                        otp
                    )

                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(
                            { onSuccess(it) },
                            { onFailure(it) }
                        )
                }
                Const.OTP_BY_SMS -> {
                    val ser = service.verifyOtp(
                        prefs[Const.T_MOBILE_KEY],
                        prefs[Const.T_COUNTRYCODE_KEY],
                        "",
                        otp
                    )

                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(
                            { onSuccess(it) },
                            { onFailure(it) }
                        )
                }
                Const.OTP_BY_MAIL -> {
                    val ser = service.verifyOtp(
                        "",
                        "",
                        prefs[Const.T_EMAIL_KEY],
                        otp
                    )

                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(
                            { onSuccess(it) },
                            { onFailure(it) }
                        )
                }
            }


        } else {
            Utils.showToast(this, "Please enter OTP")
        }


    }

    private fun onFailure(it: Throwable?) {
        btn_submit_otp.isEnabled = true


        ErrorUtil.handlerGeneralError(this, it!!, true)
//        ErrorHandlingClass.errorHandlingException(this, it)

        Log.d("Error", it.toString())

    }

    private fun onSuccess(it: ResponseOtp?) {
        btn_submit_otp.isEnabled = true

        Utils.showToast(this@EnterOtpActivity, it?.message.toString())

        //open generate pass activity
        val intent = Intent(this, GeneratePasswordActivity::class.java)
        intent.putExtra(Constants.INTENT_KEY_OTP_BY, otpCode)
        startActivity(intent)

        Log.d("Success", it.toString())

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_enter_otp)

        setListener()

        getIntentAction()
    }

    private fun getIntentAction() {
        intent?.extras?.let {
            otpCode = it.getString(Constants.INTENT_KEY_OTP_BY)
        }
    }

    private fun setListener() {
        back_btn.setOnClickListener(this)

        btn_submit_otp.setOnClickListener(this)

        pinview.setPinViewEventListener { pinview, fromUser ->
            //Make api calls here or what not

        }
    }

}
