package com.ondemand.api

import com.ondemand.api.model.*
import com.ondemand.model.InsListMain
import com.ondemand.model.InsuranceContent
import com.ondemand.utils.BaseResponse
import com.ondemand.utils.CallbackWrapper
import io.reactivex.Observable
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.http.*

interface ApiInterface {

    /*  "rutNumber":"45436345662437",
        "medicalInsurance":"334er3543",
        "mobile":"354343474406645",
        "countryCode":"54",
        "email":"su134020@gmail.com",
        "latitude":"28",
        "longitude":"77",
        "password":"1234"   ,
        "deviceToken":"13234547fvfdd",
        "deviceType":1  */
    @FormUrlEncoded
    @POST(Const.SIGNUP_KEY)
    fun signup(/*@Header ("accessToken")accessToken : String,*/
        @Field("rutNumber") rut: String,
        @Field("medicalInsurance") medIns: String,
        @Field("mobile") mobile: String,
        @Field("countryCode") countryc: String,
        @Field("email") email: String,
        @Field("latitude") latitude: String,
        @Field("longitude") longitude: String,
        @Field("password") password: String,
        @Field("deviceToken") devToken: String,
        @Field("deviceType") devType: String
    ): Observable<ResponseSignUp>


    /* "rutNumber": "4543666437",
       "latitude": "28",
       "longitude": "77",
       "password": "1234",
       "deviceToken": "13254vfdd",
       "deviceType": 1*/
    @FormUrlEncoded
    @POST(Const.SIGNIN_KEY)
    fun signIn(/*@Header ("accessToken")accessToken : String,*/
        @Field("rutNumber") rut: String,
        @Field("latitude") latitude: String,
        @Field("longitude") longitude: String,
        @Field("password") password: String,
        @Field("deviceToken") devToken: String,
        @Field("deviceType") devType: String
    ): Observable<ResponseSignin>

    /*{
"mobile":"",
"countryCode":"",
"email":"su100@gmail.com",
"type":1
}*/

    @FormUrlEncoded
    @POST(Const.FORGOT_PASSWORD)
    fun forgotPassword(/*@Header ("accessToken")accessToken : String,*/
        @Field("mobile") mobile: String,
        @Field("countryCode") countryc: String,
        @Field("email") email: String,
        @Field("type") devType: String
    ): Observable<ResponseOtp>

    /*{
    "mobile":"1234567890",
    "countryCode":"91",
    "email":"",
    "verificationCode":"1234"
    }*/
    @FormUrlEncoded
    @POST(Const.VERIFYOTP)
    fun verifyOtp(/*@Header ("accessToken")accessToken : String?,*/
        @Field("mobile") mobile: String?,
        @Field("countryCode") countryc: String?,
        @Field("email") email: String?,
        @Field("verificationCode") code: String?
    ): Observable<ResponseOtp>

    /*{
        "mobile":"0987654321",
        "countryCode":"91",
        "email":"qwe@gmail.com",
        "password":"123456"
        }*/

    @FormUrlEncoded
    @POST(Const.RESETPASSWORD)
    fun resetPassword(/*@Header ("accessToken")accessToken : String?,*/
        @Field("mobile") mobile: String?,
        @Field("countryCode") countryc: String?,
        @Field("email") email: String?,
        @Field("password") password: String?
    ): Observable<ResponseOtp>

    //    /user/verifyRut
    @FormUrlEncoded
    @POST(Const.RUT_VERIFY)
    fun verifyRUT(/*@Header ("accessToken")accessToken : String?,*/
        @Field("rutNumber") rut: String?
        /* @Field("countryCode") countryc: String?,
         @Field("email") email: String?,
         @Field("password") password: String?*/
    ): Observable<RUTVerify>

    //    /user/validateInsurance
    @FormUrlEncoded
    @POST(Const.VAL_INSURANCE)
    fun validateInsurance(/*@Header ("accessToken")accessToken : String?,*/
        @Field("rutNumber") rut: String?,
        @Field("password") password: String?,
        @Field("siteName") sitename: String?
    ): Observable<CommonResp>


    @GET(Const.GET_INSURANCE)
    fun getInsuranceList(/*@Header ("accessToken")accessToken : String?,*/
    ): Observable<InsListMain>


    @FormUrlEncoded
    @POST(Const.VAL_PHONE)
    fun formatPhoneNo(/*@Header ("accessToken")accessToken : String?,*/
        @Field("countryCode") countryCode: String?,
        @Field("mobile") mobile: String?,
        @Field("countryCodeName") countryCodeName: String?
    ): Observable<CommonResp>


    @FormUrlEncoded
    @POST(Const.RUT_DETAIL)
    fun getRUTDetail(/*@Header ("accessToken")accessToken : String?,*/
            @Field("rutNumber") rutNumber: String?
    ): Observable<RUTDetails>

    @FormUrlEncoded
    @POST(Const.CHANGE_PASSWORD)
    fun changePassword(@Header ("access_token")accessToken : String?,
        @Field("password") password: String?,
        @Field("newPassword") newPassword   : String?
    ): Observable<CommonResp>


    @Multipart
    @POST(Const.EDIT_PROFILE)
    fun editProfile(@Header ("access_token")accessToken : String?,
                    @Part("email") email: RequestBody?,
                    @Part("countryCode") countryCode: RequestBody?,
                    @Part("mobile") mobile: RequestBody?,
                    @Part profileImage: MultipartBody.Part?
    ): Observable<ResponseSignUp>

    @POST(Const.LOGOUT)
    fun logout(/*@Header ("accessToken")accessToken : String?,*/
        @Header("access_token") accessToken: String?
    ): Observable<CommonResp>

}