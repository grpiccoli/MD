package com.ondemand.model


data class InsListMain(val message: String, val response : List<InsuranceContent>)

class InsuranceContent(/*siteName1: String, incicon: Drawable?*/) {
    var siteName: String? = ""
    var siteUrl: String? = ""
    var _id: String? = ""


    /*init {
        siteName = siteName1
        inc_icon = incicon
    }*/

}