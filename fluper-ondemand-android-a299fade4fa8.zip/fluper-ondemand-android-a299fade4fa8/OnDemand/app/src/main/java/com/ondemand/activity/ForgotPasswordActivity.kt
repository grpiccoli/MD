package com.ondemand.activity

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import com.ondemand.R
import com.ondemand.api.ApiClient
import com.ondemand.api.ApiInterface
import com.ondemand.api.Const
import com.ondemand.api.model.ResponseOtp
import com.ondemand.storage.PreferenceHelper
import com.ondemand.storage.PreferenceHelper.set
import com.ondemand.utils.Constants
import com.ondemand.utils.Utils
import com.ondemand.utils.ErrorUtil
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_forgot_password.*
import kotlinx.android.synthetic.main.toolbar.back_btn

class ForgotPasswordActivity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(v: View?) {

        when (v?.id) {

            R.id.back_btn -> {
                onBackPressed()
            }
            R.id.ll_get_phone_call -> {
                val intent = Intent(this, ForgotPassNumberActivity::class.java)
                intent.putExtra(Constants.INTENT_KEY_OTP_BY, Constants.INTENT_VAL_OTP_BY_CALL)
                startActivity(intent)

            }
            R.id.ll_get_otp_sms -> {
                val intent = Intent(this, ForgotPassNumberActivity::class.java)
                intent.putExtra(Constants.INTENT_KEY_OTP_BY, Constants.INTENT_VAL_OTP_BY_SMS)
                startActivity(intent)

            }
            R.id.btnRecoverPass -> {
                validateNCheck()
            }
        }
    }

    private fun validateNCheck() {
        val email = edtEmailAddress.text.toString()

        var isValid = true

        if (email.isEmpty()) {
            isValid = false
            edtEmailAddress.setError("Email address is empty")

        } else if (!Utils.isValidEmail(email)){
            isValid = false
            edtEmailAddress.setError("Email address is invalid")

        }

        if (isValid){
            btnRecoverPass.isEnabled = false

            val prefs = PreferenceHelper.customPrefs(applicationContext)
            prefs[Const.T_EMAIL_KEY]= email

            val service = ApiClient.client.create(ApiInterface::class.java)
            val ser = service.forgotPassword("", "", email, Const.OTP_BY_MAIL)

                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { onSuccess(it) },
                    { onFailure(it) }
                )
        }

    }

    private fun onFailure(it: Throwable?) {
        btnRecoverPass.isEnabled = true

        ErrorUtil.handlerGeneralError(this, it!!, true)
//        ErrorHandlingClass.errorHandlingException(this, it)
        Log.d("Error", it.toString())

    }

    private fun onSuccess(it: ResponseOtp?) {
        btnRecoverPass.isEnabled = true

        Utils.showToast(this@ForgotPasswordActivity, it?.message.toString())

        //open generate pass activity
        val intent = Intent(this, EnterOtpActivity::class.java)
        intent.putExtra(Constants.INTENT_KEY_OTP_BY, Const.OTP_BY_MAIL)
        startActivity(intent)

        Log.d("Success", it.toString())

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)

        setListener()
    }

    private fun setListener() {
        back_btn.setOnClickListener(this)
        ll_get_phone_call.setOnClickListener(this)
        ll_get_otp_sms.setOnClickListener(this)
        btnRecoverPass.setOnClickListener(this)

    }
}
