package com.ondemand.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.ondemand.storage.StorageUtils
import java.io.*

object ImageUtils{

    fun compressImageFile(context: Context, pathUri: Uri): File {
        var b: Bitmap? = null

        var realPath: String? = StorageUtils.getRealPathFromURI(context, pathUri)
        var f: File = File(realPath)

        //Decode image size
        var o: BitmapFactory.Options = BitmapFactory.Options();
        o.inJustDecodeBounds = true;

        var fis: FileInputStream
        try {
            fis = FileInputStream(f);
            BitmapFactory.decodeStream(fis, null, o);
            fis.close();
        } catch (e: FileNotFoundException) {
            e.printStackTrace();
        } catch (e: IOException) {
            e.printStackTrace();
        }

        val IMAGE_MAX_SIZE = 1024;
        var scale = 1;
        if (o.outHeight > IMAGE_MAX_SIZE || o.outWidth > IMAGE_MAX_SIZE) {
            scale = Math.pow(
                2.0,
                Math.ceil(Math.log(IMAGE_MAX_SIZE / Math.max(o.outHeight, o.outWidth).toDouble()) / Math.log(0.5))
            ).toInt();
        }

        //Decode with inSampleSize
        var o2: BitmapFactory.Options = BitmapFactory.Options();
        o2.inSampleSize = scale;
        try {
            fis = FileInputStream(f);
            b = BitmapFactory.decodeStream(fis, null, o2);
            fis.close();
        } catch (e: FileNotFoundException) {
            e.printStackTrace();
        } catch (e: IOException) {
            e.printStackTrace();
        }

// Log.d(TAG, "Width :" + b.getWidth() + " Height :" + b.getHeight());

        var destFile = File(StorageUtils.getImageFilePath());
        try {
            var out: FileOutputStream = FileOutputStream(destFile);
            b?.compress(Bitmap.CompressFormat.PNG, 85, out);
            out.flush();
            out.close();

        } catch (e: Exception) {
            e.printStackTrace();
        }
        return destFile;
    }
}