package com.ondemand.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.ondemand.R
import com.ondemand.utils.Constants
import kotlinx.android.synthetic.main.appoint_booked_success_layout.*

class AppointmentBookedActivity : AppCompatActivity(), View.OnClickListener {

    private var code: Int = 0

    override fun onClick(v: View?) {
        when (v?.id){
            R.id.appoint_booked_ ->{
                when(code) {
                    Constants.INTENT_VAL_CHATDOC -> {
                        startActivity(Intent(this, ChattingActivity::class.java))
                        finish()

                    }
                    else -> {
                        startActivity(Intent(this, BookingDetailsActivity::class.java))
                        finish()
                    }
                }

            }
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.appoint_booked_success_layout)

        initUi()

        setListener()
        getIntentAction()
    }

    override fun onBackPressed() {
        //empty method
    }

    private fun setListener() {
        appoint_booked_.setOnClickListener(this)

    }

    private fun getIntentAction() {
        intent?.extras?.let {
            code = it.getInt(Constants.INTENT_KEY_CHAT_PAY)
        }

    }


    private fun initUi() {

    }
}
