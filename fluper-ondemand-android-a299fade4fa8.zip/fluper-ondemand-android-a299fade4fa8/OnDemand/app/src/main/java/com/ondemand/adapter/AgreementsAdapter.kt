package com.ondemand.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.RadioGroup
import com.ondemand.R
import com.ondemand.customview.CFTextView
import com.ondemand.model.InsuranceContent

class AgreementsAdapter(context: Context, _array: MutableList<String>, listener: View.OnClickListener) :
    RecyclerView.Adapter<AgreementVh>() {

    var listItems: MutableList<String> = mutableListOf()
    var mContext: Context? = null
    var mListener: View.OnClickListener? = null

    init {
        mContext = context
        listItems = _array

        mListener = listener
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): AgreementVh {
        val inflater = LayoutInflater.from(p0.context)

        return AgreementVh(inflater, p0)

    }

    override fun getItemCount(): Int {

        return listItems.size

    }

    override fun onBindViewHolder(vh: AgreementVh, p1: Int) {

        vh.selectedRB?.setText("" + listItems.get(p1))
//        vh.selectedRB?.setCompoundDrawablesWithIntrinsicBounds(null, null,
//            listItems.get(p1).inc_icon, null)

//        rg?.addView(vh.selectedRB)

//        vh.selectedRB?.setOnClickListener(mListener)

    }

}

class AgreementVh(view: LayoutInflater, parent: ViewGroup) :
    RecyclerView.ViewHolder(view.inflate(R.layout.dialog_list_item, parent, false)) {

    var selectedRB: CFTextView? = null
//
    init {

        selectedRB = itemView.findViewById(R.id.select_btn)

    }

}