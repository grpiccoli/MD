package com.ondemand.api.model

class ResponseSignUp  {
    var message :String? = ""
    var response : Otp? = null
}