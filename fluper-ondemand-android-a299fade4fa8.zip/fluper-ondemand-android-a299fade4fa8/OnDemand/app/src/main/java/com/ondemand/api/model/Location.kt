package com.ondemand.api.model

class Location {
    var type: String? = ""
    var coordinates: MutableList<Float>? = mutableListOf()
    var default: MutableList<String>? = mutableListOf()

}