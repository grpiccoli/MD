package com.ondemand.adapter

import android.content.Context
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.ondemand.R
import com.ondemand.activity.ChattingActivity

class DoctorOnlineAdapter(context: Context) : RecyclerView.Adapter<DoctorOnlineAdapter.DocOnlVHolder>() {


    override fun onCreateViewHolder(viewGroup: ViewGroup, p1: Int): DocOnlVHolder {
        return DocOnlVHolder(
            LayoutInflater.from(viewGroup.context).inflate(
                R.layout.available_docs_list_item,
                viewGroup,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return 7
    }

    override fun onBindViewHolder(p0: DocOnlVHolder, p1: Int) {
        p0.itemView.setOnClickListener{
            mContext.startActivity(Intent(mContext, ChattingActivity::class.java))

        }
    }

    private val mContext: Context

    init {
        mContext = context
    }

    class DocOnlVHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        override fun onClick(v: View?) {

            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        }

        init {
//            v.setOnClickListener(this)
        }

    }
}