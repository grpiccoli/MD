package com.ondemand.api.model

data class MedInsuranceList(val message: String, val response: List<Insurance>) {
//    {
//        "message": "Site list.",
//        "response": [
//        {
//            "siteName": "Banmedica",
//            "siteUrl": "https://www.isaprebanmedica.cl/LoginBanmedica.aspx",
//            "_id": "5cef9a2066f49713ccc7e23f"
//        },
//        {
//            "siteName": "Colmena",
//            "siteUrl": "https://www.colmena.cl/afiliados/#/login",
//            "_id": "5cef9a2066f49713ccc7e240"
//        }
//        ]
//    }


}

data class Insurance(val siteName: String, val siteUrl: String, val _id: String) {
    //        {
    //            "siteName": "Banmedica",
    //            "siteUrl": "https://www.isaprebanmedica.cl/LoginBanmedica.aspx",
    //            "_id": "5cef9a2066f49713ccc7e23f"
    //        },

}