package com.ondemand.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.util.Log
import android.view.View
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.ondemand.R
import com.ondemand.adapter.SettingsAdapter
import com.ondemand.api.model.ApiMethods
import com.ondemand.utils.Constants
import kotlinx.android.synthetic.main.activity_setting.*
import kotlinx.android.synthetic.main.toolbar_with_nno_bg.*

class SettingActivity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.back_btn -> {
                onBackPressed()
            }

            R.id.circleImageView2 -> {
                startActivity(Intent(this, ProfileEditActivity::class.java))
            }

//            R.id.tv_terms_cond -> {
//                openInfoActivity(Constants.INTENT_VAL_OPEN_TERMSN)
//
//            }
//
//            R.id.tv_priv_pol -> {
//                openInfoActivity(Constants.INTENT_VAL_OPEN_PRIVCY_POL)
//            }
//
//            R.id.tv_about -> {
//                openInfoActivity(Constants.INTENT_VAL_OPEN_ABOUTUS)
//            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting)

        initUi()

        setListener()
    }

    private fun initUi() {
        toolbar_text.setText("Settings")
        setting_recyview.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        setting_recyview.adapter = SettingsAdapter(this)

        try {
            Glide.with(this)
                .load(ApiMethods.getProfileImageURL(this)).placeholder(R.drawable.place_holder)
                .error(R.drawable.place_holder)// Remote URL of image.
                .into(circleImageView2 as ImageView)
        } catch (E : UnsupportedOperationException){
            Log.e("Error", E.message)
        }
    }
    private fun setListener() {
        back_btn.setOnClickListener(this)

        circleImageView2.setOnClickListener(this)
//        tv_terms_cond.setOnClickListener(this)
//        tv_priv_pol.setOnClickListener(this)
//        tv_about.setOnClickListener(this)
    }
}
