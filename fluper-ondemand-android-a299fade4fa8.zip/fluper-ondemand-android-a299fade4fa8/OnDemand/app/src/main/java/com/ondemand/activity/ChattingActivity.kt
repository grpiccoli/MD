package com.ondemand.activity

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.ondemand.R
import com.ondemand.adapter.ChattingAdapter
import kotlinx.android.synthetic.main.activity_chatting.*

class ChattingActivity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(v: View?) {

        when (v?.id) {
            R.id.close_btn -> {
                val intent = Intent(this, MapsHomeActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK

                startActivity(intent)
                finish()
            }
            R.id.videocall -> {
                startActivity(Intent(this, CallingActivity::class.java))

            }
            R.id.audiocall -> {
                startActivity(Intent(this, CallingActivity::class.java))

            }
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chatting)

        initUi()
        setListener()
    }

    private fun initUi() {
        chat_recycler_view.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        (chat_recycler_view.layoutManager as LinearLayoutManager).stackFromEnd = true
        chat_recycler_view.adapter = ChattingAdapter(this)
    }

    private fun setListener() {
        close_btn.setOnClickListener(this)
        videocall.setOnClickListener(this)
        audiocall.setOnClickListener(this)
    }
}
