package com.ondemand.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.ondemand.R
import kotlinx.android.synthetic.main.activity_chat_with_doc_2.*
import kotlinx.android.synthetic.main.toolbar.*

class ChatWithDoc2Activity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.back_btn -> {
                onBackPressed()
            }
            R.id.btn_startChat -> {
                startActivity(Intent(this, ChatWithDoc3Activity::class.java))

            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat_with_doc_2)

        initUi()

        setListener()
    }

    private fun initUi() {
        toolbar_text.isAllCaps = false
        toolbar_text.text = "Start a New Chat"

    }

    private fun setListener() {

        back_btn.setOnClickListener(this)
        btn_startChat.setOnClickListener(this)
    }
}
