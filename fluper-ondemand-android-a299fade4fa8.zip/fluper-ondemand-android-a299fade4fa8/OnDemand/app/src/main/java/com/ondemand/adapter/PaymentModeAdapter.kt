package com.ondemand.adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import com.ondemand.R

class PaymentModeAdapter : RecyclerView.Adapter<PaymentModeAdapter.PaymentModeVH>() {

    private val images : List<Int> = listOf(R.drawable.webpay_fittex,
                                            R.drawable.khipu_pay,
                                            R.drawable.paypal_pay)

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): PaymentModeVH {
        return PaymentModeVH(
            LayoutInflater.from(viewGroup.context).inflate(
                R.layout.radio_image_lyt_item,
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(pmyntVholder: PaymentModeVH, i: Int) {
        pmyntVholder.radioBtn.setCompoundDrawablesWithIntrinsicBounds(0, 0, images[i%3], 0)
    }

    override fun getItemCount(): Int {
        return 3
    }

    class PaymentModeVH(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {

        val radioBtn : RadioButton

        override fun onClick(v: View?) {

            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        }

        init {
//            v.setOnClickListener(this)
            radioBtn = itemView.findViewById(R.id.radio)
        }

    }

}



