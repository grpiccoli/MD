package com.ondemand.storage

import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.support.v4.app.ActivityCompat.startActivityForResult
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.text.TextUtils
import java.io.ByteArrayOutputStream
import java.io.File

class StorageUtils {
    companion object {
        internal val GALLERY_CONSTANT = 12
        internal val CAMERA_CONSTANT = 20

        val REQUEST_PERMISSION_SETTING: Int = 101

        internal fun captureImage(context: Context) {
            val option = arrayOf("Camera", "Gallery")
            val builder = AlertDialog.Builder(context)
            builder.setTitle("Complete action using")
            builder.setItems(option) { dialogInterface, i ->

                if (i == 0) {
                    openCamera(context as AppCompatActivity)
                } else if (i == 1) {
                    openGallery(context as AppCompatActivity)
                }
            }

            builder.show()
        }

        private fun openCamera(activity: AppCompatActivity) {
            val cameraintent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(activity, cameraintent, CAMERA_CONSTANT, null)

        }

        private fun openGallery(activity: AppCompatActivity) {
            val galleryintent = Intent(Intent.ACTION_GET_CONTENT)
            galleryintent.type = "image/*"
            startActivityForResult(activity, galleryintent, GALLERY_CONSTANT, null)

        }

        internal fun getImageFilePath(): String {
            val file = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES + "/Ondemand");
            if (!file.exists()) {
                file.mkdirs()
            }
            return file.getAbsolutePath() + "/IMG_" + System.currentTimeMillis() + ".jpg"
        }

        internal fun getRealPathFromURI(context: Context, contentUri: Uri?): String? {
            var contentUri = contentUri
            var cursor: Cursor?
            var filePath: String? = ""
            if (contentUri == null)
                return filePath

            val file = File(contentUri.path)
            if (file.exists())
                filePath = file.getPath()
            if (!TextUtils.isEmpty(filePath))
                return filePath
            val proj = arrayOf(MediaStore.Images.Media.DATA)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                try {
                    val wholeID = DocumentsContract.getDocumentId(contentUri)
                    // Split at colon, use second item in the array
                    //                String[] split = wholeID.split(":");
                    val id: String
                    if (wholeID.contains(":"))
                        id = wholeID.split(":".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()[1]
                    else
                        id = wholeID
                    //                if (split.length > 1)
                    //                    id = split[1];
                    //                else id = wholeID;
                    // where id is equal to
                    cursor = context.contentResolver.query(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        proj,
                        MediaStore.Images.Media._ID + "='" + id + "'",
                        null,
                        null
                    )
                    if (cursor != null) {
                        val columnIndex = cursor.getColumnIndex(proj[0])
                        if (cursor.moveToFirst())
                            filePath = cursor.getString(columnIndex)
                        if (!TextUtils.isEmpty(filePath))
                            contentUri = Uri.parse(filePath)
                    }
                } catch (e: IllegalArgumentException) {
                    e.printStackTrace()
                }

            }
            if (!TextUtils.isEmpty(filePath))
                return filePath
            try {
                cursor = context.contentResolver.query(contentUri!!, proj, null, null, null)
                if (cursor == null)
                    return contentUri.path
                val column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
                if (cursor.moveToFirst())
                    filePath = cursor.getString(column_index)
                if (!cursor.isClosed)
                    cursor.close()
            } catch (e: Exception) {
                e.printStackTrace()
                filePath = contentUri!!.path
            }

            if (filePath == null)
                filePath = ""
            return filePath
        }

        internal  fun getImageUri(context: Context, inImage: Bitmap): Uri {
            val bytes = ByteArrayOutputStream()
            inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
            val path = MediaStore.Images.Media.insertImage(
                context.contentResolver, inImage,
                "Title", null
            )
            return Uri.parse(path)
        }

    }
}