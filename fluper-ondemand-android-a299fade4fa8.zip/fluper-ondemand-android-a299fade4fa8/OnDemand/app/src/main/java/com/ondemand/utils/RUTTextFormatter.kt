package com.ondemand.utils

import android.telephony.PhoneNumberFormattingTextWatcher
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import kotlinx.android.synthetic.main.activity_sign_in.*
import java.lang.Exception

class RUTTextFormatter(val edt: EditText) : TextWatcher {

    var prevL = 0
    override fun afterTextChanged(s: Editable?) {


    }

    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        val length = s!!.length
        if (prevL < length) {
            var ss = s.toString()
            ss = ss.replace("-", "")
                .replace(".", "")
                .replace(" ", "")

            val str: StringBuilder = StringBuilder(ss)

            val len = ss.length
            if (len in 2..12) {

                if (len >= 2) {
                    str.insert(ss.length - 1, "-")

                    if ((len - 2) / 3 >= 1) {
                        str.insert(ss.length - 4, ".")

                        if ((len - 2) / 3 >= 2) {
                            str.insert(ss.length - 7, ".")
                        }

                    }
                    edt.removeTextChangedListener(this)
                    try {
                        edt.setText(str.toString())
                        edt.setSelection(str.length)
                    } catch (r: Exception) {
                        println(r.cause)
                    } finally {
                        print("Invalid input... ")
                    }

                    edt.addTextChangedListener(this)

                    return
                }


            }
        }
    }

    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
        prevL = edt.text!!.length

    }

}