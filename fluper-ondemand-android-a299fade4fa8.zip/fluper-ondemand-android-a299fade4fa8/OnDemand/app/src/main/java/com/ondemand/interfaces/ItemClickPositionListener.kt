package com.ondemand.interfaces

interface ItemClickPositionListener {
    fun onItemClick(pos : Int)
}