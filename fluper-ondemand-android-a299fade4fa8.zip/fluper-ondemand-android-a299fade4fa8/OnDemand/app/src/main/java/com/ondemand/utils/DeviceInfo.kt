package com.ondemand.utils

import android.content.Context
import android.provider.Settings
import java.util.*

class DeviceInfo {
    companion object{
        fun getDeviceId(context: Context) : String{
            return Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        }

        fun getDeviceUUID(): String {
            return UUID.randomUUID().toString()

        }
    }
}