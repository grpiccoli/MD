package com.ondemand.api.model

data class RUTVerify(val message: String?,
                     val response: RUTResponse?) {
//    {
//        "message": "true",
//        "response": true
//    }
//    {
//        "result": true,
//        "formattedRutNo": "11.927.437-0"
//    }

    data class RUTResponse(val result: String?,
                           val formattedRutNo: String?){

    }

}