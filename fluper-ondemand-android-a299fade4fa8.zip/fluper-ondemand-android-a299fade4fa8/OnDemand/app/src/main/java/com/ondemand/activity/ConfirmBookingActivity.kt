package com.ondemand.activity

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import com.ondemand.R
import kotlinx.android.synthetic.main.activity_confirm_booking.*

class ConfirmBookingActivity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(v: View?) {
        when (v?.id) {

            R.id.back_btn -> {
                onBackPressed()
            }

            R.id.btn_proceedBook -> {
                startActivity(Intent( this, SelectPaymentModeActivity::class.java))
            }

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_confirm_booking)


        setListener()
    }

    private fun setListener() {
        back_btn.setOnClickListener(this)
        btn_proceedBook.setOnClickListener(this)
    }
}
