package com.ondemand.activity

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import com.ondemand.R
import com.ondemand.api.ApiClient
import com.ondemand.api.ApiInterface
import com.ondemand.api.Const
import com.ondemand.api.model.ResponseOtp
import com.ondemand.storage.PreferenceHelper
import com.ondemand.storage.PreferenceHelper.get
import com.ondemand.storage.PreferenceHelper.set
import com.ondemand.utils.Utils
import com.ondemand.utils.ErrorUtil
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_generate_password.*

class GeneratePasswordActivity : AppCompatActivity(), View.OnClickListener {

    override fun onClick(v: View?) {
        when (v?.id) {

            R.id.back_btn -> {
                onBackPressed()
            }

            R.id.btn_done_gen -> {
//                showDialog()
                validateNCheck()
            }
        }
    }

    private fun validateNCheck() {

        val newPass = edtNewPass.text.toString()
        val reenterPass = edtReenterNewpass.text.toString()

        var isValid = true

        if (newPass.isEmpty()) {
            isValid = false
            edtNewPass.setError("New password field is empty")

        } else if (!(newPass.length >= 6 && newPass.length <= 14)) {
            isValid = false
            edtNewPass.setError("New Password length must be in range 6-14")
        }

        if (reenterPass.isEmpty()) {
            isValid = false
            edtReenterNewpass.setError("Reenter password field is empty")

        } else if (!reenterPass.equals(newPass)) {
            isValid = false
            edtReenterNewpass.setError("Reenter Password is not matching")

        }

        if (isValid) {
            val service = ApiClient.client.create(ApiInterface::class.java)
            val prefs = PreferenceHelper.customPrefs(applicationContext)

            btn_done_gen.isEnabled = false
            val ser = service.resetPassword(
                mobile = prefs[Const.T_MOBILE_KEY],
                countryc = prefs[Const.T_COUNTRYCODE_KEY],
                email = prefs[Const.T_EMAIL_KEY],
                password = newPass

            )

                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { onSuccess(it) },
                    { onFailure(it) }
                )
        }

    }

    private fun onSuccess(it: ResponseOtp?) {
        btn_done_gen.isEnabled = true
        Utils.showToast(this@GeneratePasswordActivity, it?.message.toString())

        //success
        showDialog()

        Log.d("Success", it.toString())

    }

    private fun onFailure(it: Throwable?) {
        btn_done_gen.isEnabled = true

        ErrorUtil.handlerGeneralError(this, it!!, true)
//        ErrorHandlingClass.errorHandlingException(this, it)
        Log.d("Error", it.toString())

    }

    private fun showDialog() {
        val alert = Utils.showDialog(
            this, R.layout.pass_recover_dialog_layout/*, DialogInterface.OnDismissListener {
            it.dismiss()
            val intent = Intent(this@GeneratePasswordActivity, SignInActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
        }*/
        )

        alert.setCancelable(false)
        alert.findViewById<View>(R.id.alert_dialog)?.setOnClickListener {
            alert.dismiss()

            clearTempOTPVals()

            val intent = Intent(this@GeneratePasswordActivity, SignInActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_generate_password)

        setListener()
    }

    fun clearTempOTPVals() {
        val prefs = PreferenceHelper.customPrefs(applicationContext)
        prefs[Const.T_MOBILE_KEY] = ""
        prefs[Const.T_COUNTRYCODE_KEY] = ""
        prefs[Const.T_EMAIL_KEY] = ""
    }

    private fun setListener() {
        back_btn.setOnClickListener(this)

        btn_done_gen.setOnClickListener(this)
    }

}
