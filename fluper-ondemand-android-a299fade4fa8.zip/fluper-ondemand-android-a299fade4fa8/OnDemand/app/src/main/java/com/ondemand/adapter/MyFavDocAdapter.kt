package com.ondemand.adapter

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.ondemand.R
import com.ondemand.activity.SetTimeSlotActivity
import com.ondemand.customview.CFButton
import com.ondemand.utils.Constants

class MyFavDocAdapter(context : Context)  : RecyclerView.Adapter<MyFavDocAdapter.ServiceProvViewHolder>() {
    private val mContext : Context

    init {
        mContext = context
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ServiceProvViewHolder {
        return ServiceProvViewHolder(
            LayoutInflater.from(viewGroup.context).inflate(
                R.layout.my_fav_doc_list_item,
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(aDepViewHolder: ServiceProvViewHolder, i: Int) {

        aDepViewHolder.itemView.findViewById<CFButton>(R.id.btn_book)?.setOnClickListener {
            val intent = Intent(mContext, SetTimeSlotActivity::class.java)
            intent.putExtra(Constants.INTENT_KEY_SETTIMESLOT, Constants.INTENT_VAL_SERVICEPROV)

            mContext.startActivity(intent)
            (mContext as AppCompatActivity).finish()
        }

    }

    override fun getItemCount(): Int {
        return 2
    }

    class ServiceProvViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        override fun onClick(v: View?) {

            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        }

        init {
//            v.setOnClickListener(this)
        }

    }

}



