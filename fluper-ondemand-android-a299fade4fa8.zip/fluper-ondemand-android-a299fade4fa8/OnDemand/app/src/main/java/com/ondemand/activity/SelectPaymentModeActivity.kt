package com.ondemand.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.ondemand.R
import com.ondemand.adapter.PaymentModeAdapter
import com.ondemand.utils.Constants
import kotlinx.android.synthetic.main.activity_select_payment_mode.*
import kotlinx.android.synthetic.main.toolbar.*

class SelectPaymentModeActivity : AppCompatActivity(), View.OnClickListener {
    private var code: Int = 0

    override fun onClick(v: View?) {

        when (v?.id) {

            R.id.back_btn -> {
                onBackPressed()
            }

            R.id.btnproceed -> {
                val intent = Intent( this, SummaryActivity::class.java)
                intent.putExtra(Constants.INTENT_KEY_CHAT_PAY, code)

                startActivity(intent)
            }

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_select_payment_mode)

        initUi()
        setListener()

        getIntentAction()
    }


    private fun getIntentAction() {
        intent?.extras?.let {
            code = it.getInt(Constants.INTENT_KEY_CHAT_PAY)
        }

    }

    private fun initUi() {

        toolbar_text.text = "Select Payment Mode"

        recyclerview.layoutManager = LinearLayoutManager(this,
            LinearLayoutManager.VERTICAL, false)
        recyclerview.adapter = PaymentModeAdapter()

    }

    private fun setListener() {
        back_btn.setOnClickListener(this)
        btnproceed.setOnClickListener(this)
    }

}
