package com.ondemand.activity

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View
import com.ondemand.R
import com.ondemand.adapter.MedInsuranceAdapter
import com.ondemand.api.ApiClient
import com.ondemand.api.ApiInterface
import com.ondemand.interfaces.ItemClickPositionListener
import com.ondemand.model.InsuranceContent
import kotlinx.android.synthetic.main.activity_recover_password.*
import kotlinx.android.synthetic.main.toolbar.*

class RecoverPasswordActivity : AppCompatActivity(), View.OnClickListener {


    val service = ApiClient.client.create(ApiInterface::class.java)
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.back_btn -> {
                onBackPressed()
            }
            R.id.edtEmailAddress -> {

                showDialog()
            }

            R.id.btnRecoverPass -> {
                startActivity(Intent(this, RequestPasswordActivity::class.java))
                finish()
            }
        }

    }

    private fun showDialog() {
        val builderSingle = AlertDialog.Builder(this@RecoverPasswordActivity)
        val recList = RecyclerView(this)
        var alertdd: AlertDialog? = null
        recList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        builderSingle.setView(recList)

        val array= mutableListOf<InsuranceContent>()
//        arrayAdapter.add(InsuranceContent("Particular ", ContextCompat.getDrawable(this, R.drawable.particular)))
//        arrayAdapter.add(InsuranceContent("Fonasa ", ContextCompat.getDrawable(this, R.drawable.fonasa)))
//        arrayAdapter.add(InsuranceContent("Consalud ", ContextCompat.getDrawable(this, R.drawable.consalud)))
//        arrayAdapter.add(InsuranceContent("Cruz Blanca ", ContextCompat.getDrawable(this, R.drawable.cruz)))
//        arrayAdapter.add(InsuranceContent("Nueva Más Vida ", ContextCompat.getDrawable(this, R.drawable.masvida)))
//        arrayAdapter.add(InsuranceContent("Vida Tres ", ContextCompat.getDrawable(this, R.drawable.vidatres)))

        val adapter = MedInsuranceAdapter(this, array, object : ItemClickPositionListener {
            override fun onItemClick(pos: Int) {

                startActivity(Intent(this@RecoverPasswordActivity, RequestPasswordActivity::class.java))
                finish()
            }
        })

//        service.getInsuranceList().subscribeOn(Schedulers.io())
//            .observeOn(AndroidSchedulers.mainThread())
//            .subscribe(
//                {
//                    array.addAll(it)
//                    adapter.notifyItemRangeInserted(0, it.size)
//                },
//                {}
//            )

        recList.adapter = adapter

        alertdd = builderSingle.show()

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_recover_password)

        initUi()
        setListener()
    }

    private fun initUi() {
        toolbar_text.text = "Recover Password"

    }

    private fun setListener() {
        back_btn.setOnClickListener(this)
        edtEmailAddress.setOnClickListener(this)
        btnRecoverPass.setOnClickListener(this)
    }
}
