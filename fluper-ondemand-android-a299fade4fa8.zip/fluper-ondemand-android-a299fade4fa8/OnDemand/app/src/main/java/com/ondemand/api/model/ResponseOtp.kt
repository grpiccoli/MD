package com.ondemand.api.model

class ResponseOtp  {
    var message :String? = ""
    var response : Otp? = null
}