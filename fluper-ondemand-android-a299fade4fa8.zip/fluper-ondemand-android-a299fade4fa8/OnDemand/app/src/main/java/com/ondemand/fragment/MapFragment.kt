package com.ondemand.fragment

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.ondemand.R
import com.ondemand.activity.MapsHomeActivity
import kotlinx.android.synthetic.main.app_bar_maps_home.*
import kotlinx.android.synthetic.main.content_maps_home.*

class MapFragment : SupportMapFragment(), OnMapReadyCallback, View.OnClickListener {



    override fun onClick(v: View?) {
        activity!!.supportFragmentManager.beginTransaction()
            .replace(R.id.container, CitySuggestFragment(), null)
            .commit()

    }


    override fun onMapReady(p0: GoogleMap?) {
        Log.d("Googlemap", "$p0")
        p0?.let {
            it.setOnMapClickListener{

                activity!!.toolbar.title = ""
                activity!!.supportFragmentManager.beginTransaction()
                    .replace(R.id.container, CitySuggestFragment(), null)
                    .commit()
                activity!!.btn_view_as_list.visibility = View.GONE
                activity!!.ll_quick_filters.visibility = View.GONE

                (activity!! as MapsHomeActivity).drawerToggle?.isDrawerIndicatorEnabled  = false
                (activity!! as MapsHomeActivity).drawerToggle?.setHomeAsUpIndicator(R.drawable.close)

            }
        }
    }

    override fun onActivityCreated(p0: Bundle?) {
        super.onActivityCreated(p0)

    }




}