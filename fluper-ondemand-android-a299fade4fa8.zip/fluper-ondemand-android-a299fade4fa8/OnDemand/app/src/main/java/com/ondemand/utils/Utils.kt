package com.ondemand.utils

import android.content.Context
import android.content.DialogInterface
import android.support.v7.app.AlertDialog
import android.view.LayoutInflater
import android.widget.Toast
import android.util.Patterns
import android.text.TextUtils
import java.util.*
import android.content.Intent
import android.support.v4.content.ContextCompat.startActivity
import android.content.ActivityNotFoundException
import android.net.Uri
import android.support.v4.content.ContextCompat.startActivity
import com.ondemand.BuildConfig
import com.ondemand.R


class Utils {

    companion object {

        fun showDialog(context: Context, layoutInt: Int, listener: DialogInterface.OnDismissListener) {
            val mDialogView = LayoutInflater.from(context).inflate(layoutInt, null)
            //AlertDialogBuilder
            val mBuilder = AlertDialog.Builder(context)
                .setView(mDialogView)
            //show dialog
            val mAlertDialog = mBuilder.show()

            mAlertDialog.setOnDismissListener(listener)
        }

        fun showDialog(context: Context, layoutInt: Int): AlertDialog {
            val mDialogView = LayoutInflater.from(context).inflate(layoutInt, null)
            //AlertDialogBuilder
            val mBuilder = AlertDialog.Builder(context).setView(mDialogView)
            //show dialog
            val mAlertDialog = mBuilder.show()

            return mAlertDialog
        }

        fun showToast(context: Context, text: String) {
            Toast.makeText(context, text, Toast.LENGTH_LONG).show()
        }

        fun isValidEmail(target: CharSequence): Boolean {
            return Patterns.EMAIL_ADDRESS.matcher(target).matches()
        }

        fun isValidPhone(target: CharSequence): Boolean {
            return Patterns.PHONE.matcher(target).matches()
        }


        fun rateApp(context: Context) {
            val uri = Uri.parse("market://details?id=" + context.getPackageName())
            val goToMarket = Intent(Intent.ACTION_VIEW, uri)
            // To count with Play market backstack, After pressing back button,
            // to taken back to our application, we need to add following flags to intent.
            goToMarket.addFlags(
                Intent.FLAG_ACTIVITY_NO_HISTORY or
                        Intent.FLAG_ACTIVITY_NEW_DOCUMENT or
                        Intent.FLAG_ACTIVITY_MULTIPLE_TASK
            )
            try {
                context.startActivity(goToMarket)
            } catch (e: ActivityNotFoundException) {
                context.startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("http://play.google.com/store/apps/details?id=" + context.getPackageName())
                    )
                )
            }

        }

        fun shareApp(context: Context) {
            try {
                val shareIntent = Intent(Intent.ACTION_SEND)
                shareIntent.type = "text/plain"
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, context.getString(R.string.app_name))
                var shareMessage = "\nLet me recommend you this application\n\n"
                shareMessage =
                    shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n"
                shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage)
                context.startActivity(Intent.createChooser(shareIntent, "choose one"))
            } catch (e: Exception) {
                //e.toString();
            }


        }
    }

    fun getCountryCode(countryName: String) =
        Locale.getISOCountries().find { Locale("", it).displayCountry == countryName }
}