package com.ondemand.fragment

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatActivity
import android.view.View

import com.ondemand.R
import kotlinx.android.synthetic.main.toolbar.*

/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [WaitingRoomActivity.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [WaitingRoomActivity.newInstance] factory method to
 * create an instance of this fragment.
 *
 */
class WaitingRoomActivity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.back_btn -> {
                onBackPressed()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_waiting_room)

        initUi()
        setListener()

    }

    private fun initUi() {
        toolbar_text.setText("Waiting Room")

    }

    private fun setListener() {
        back_btn.setOnClickListener(this)

    }
}
