package com.ondemand.api.model

class ResponseSignin  {
    var message :String? = ""
    var response : Login? = null
}