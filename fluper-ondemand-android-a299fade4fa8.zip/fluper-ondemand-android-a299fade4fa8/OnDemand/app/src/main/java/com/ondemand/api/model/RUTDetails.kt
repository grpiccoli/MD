package com.ondemand.api.model

data class RUTDetails (val message: String?,
                       val response: RUTDetailsResponse?){}

data class RUTDetailsResponse (val name: String?,
                       val sex: String?,
                       val rut_num: String?,
                       val address: String?,
                       val comune: String?){}

//{
//    "message": "Varification successfully done.",
//    "response": {
//        "name": "Diaz Soto Maryoreth Gabriela",
//        "sex": "MUJ",
//        "rut_num": "19.674.128-3",
//        "address": "Sin Datos",
//        "comune": "Puerto Montt Centro E Isla Tenglo"
//    }
//}