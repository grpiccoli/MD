package com.ondemand.activity

import android.content.Intent
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.KeyEvent
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.ondemand.R
import com.ondemand.adapter.AgreementsAdapter
import com.ondemand.adapter.MedInsuranceAdapter
import com.ondemand.model.InsuranceContent
import com.ondemand.utils.Constants
import com.ondemand.utils.Utils
import kotlinx.android.synthetic.main.activity_view_doc_profile.*
import kotlinx.android.synthetic.main.toolbar.back_btn

class ViewDocProfileActivity : AppCompatActivity(), View.OnClickListener, OnMapReadyCallback {
    override fun onMapReady(p0: GoogleMap?) {


    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.back_btn -> {
                onBackPressed()
            }

            R.id.iv_chat_start -> {
                startActivity(Intent(this, ChatWithDocActivity::class.java))
            }

            R.id.btn_book_doc -> {
                val intent = Intent(this, SetTimeSlotActivity::class.java)
                intent.putExtra(Constants.INTENT_KEY_SETTIMESLOT, Constants.INTENT_VAL_SERVICEPROV)

                startActivity(intent)

//                startActivity(Intent(this, SetTimeSlotActivity::class.java))
            }

            R.id.btn_agreements -> {

                val alert = Utils.showDialog(this, R.layout.dialog_agreements)

                val recycler : RecyclerView? = alert.findViewById<RecyclerView>(R.id.recyclerview_ag)
                recycler?.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

                val arrayAdapter = mutableListOf<String>()
                arrayAdapter.add("1. Agreement ")
                arrayAdapter.add("2. Agreement ")
                arrayAdapter.add("3. Agreement ")
                arrayAdapter.add("4. Agreement ")
                arrayAdapter.add("5. Agreement ")
                arrayAdapter.add("6. Agreement ")

                val adapter = AgreementsAdapter(this, arrayAdapter, View.OnClickListener {

                })

                recycler?.adapter = adapter

            }
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_doc_profile)
//        maps.getMapAsync(this)

        setListener()
    }

    private fun setListener() {

        back_btn.setOnClickListener(this)
        iv_chat_start.setOnClickListener(this)
        btn_book_doc.setOnClickListener(this)
        btn_agreements.setOnClickListener(this)

    }

}
