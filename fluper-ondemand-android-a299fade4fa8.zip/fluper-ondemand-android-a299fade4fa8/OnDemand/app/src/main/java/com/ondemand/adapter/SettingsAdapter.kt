package com.ondemand.adapter

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.SwitchCompat
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.ondemand.R
import com.ondemand.activity.ChangePasswordActivity
import com.ondemand.activity.SettingActivity
import com.ondemand.activity.SignInActivity
import com.ondemand.activity.TermsnCondnActivity
import com.ondemand.api.ApiClient
import com.ondemand.api.ApiInterface
import com.ondemand.api.Const
import com.ondemand.api.model.CommonResp
import com.ondemand.customview.CFButton
import com.ondemand.interfaces.ItemClickPositionListener
import com.ondemand.storage.PreferenceHelper
import com.ondemand.storage.PreferenceHelper.get
import com.ondemand.utils.Constants
import com.ondemand.utils.Utils
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers

class SettingsAdapter(val context: Context) : RecyclerView.Adapter<RecyclerView.ViewHolder>(),
    ItemClickPositionListener {

    override fun onItemClick(pos: Int) {
        when (pos) {
            0, 1, 4, 7, 8-> {
                openInfoActivity(getConstantCode(pos))

            }
            5 -> {
                Utils.rateApp(context)

            }

            6 -> {
                Utils.shareApp(context)

            }

        }
    }

    private val mContext: Context
    val service = ApiClient.client.create(ApiInterface::class.java)

    init {
        mContext = context
    }

    private val SettingsList = listOf(
        SettingItem("Terms & Condition", R.drawable.terms, 1),
        SettingItem("Privacy Policy", R.drawable.privacy, 1),
        SettingItem("Push Notifications", R.drawable.notification, 2),
        SettingItem("App Version: 2.19.68", R.drawable.privacy, 1),
        SettingItem("About Us", R.drawable.about, 1),
        SettingItem("Rate App", R.drawable.rate, 1),
        SettingItem("Share App", R.drawable.share_app, 1),
        SettingItem("Change Password", R.drawable.key, 1),
        SettingItem("Logout", R.drawable.logout, 1)
    )

    class SettingItem(title: String, icon: Int, type: Int) {
        val mTitle: String
        val mIcon: Int
        val mType: Int

        init {
            mTitle = title
            mIcon = icon
            mType = type
        }
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewtype: Int): RecyclerView.ViewHolder {
        when (viewtype) {
            1 -> {
                return SettingViewHolder(
                    LayoutInflater.from(viewGroup.context).inflate(
                        R.layout.layout_item_settings,
                        viewGroup,
                        false
                    )
                )
            }
            2 -> {
                return SettingViewHolder2(
                    LayoutInflater.from(viewGroup.context).inflate(
                        R.layout.layout_item_settings_withswitch,
                        viewGroup,
                        false
                    )
                )
            }
        }

        return SettingViewHolder(
            LayoutInflater.from(viewGroup.context).inflate(
                R.layout.layout_item_settings,
                viewGroup,
                false
            )
        )

    }

    fun logout() {
        val prefs = PreferenceHelper.customPrefs(context)

        val ser = service.logout(
            prefs[Const.ACCESSTOKEN_KEY]
        )

            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { onSuccessPasswordChange(it) },
                { onFailure(it) }
            )
    }

    private fun onFailure(it: Throwable?) {


    }

    private fun onSuccessPasswordChange(it: CommonResp?) {
        Utils.showToast(context, "Logout Successfully")
        PreferenceHelper.clearTempOTPVals(context)
        val intent = Intent(context, SignInActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK

        context.startActivity(intent)
        (context as SettingActivity).finish()

    }

    override fun onBindViewHolder(setVholder: RecyclerView.ViewHolder, i: Int) {
        if (setVholder is SettingViewHolder) {

            setVholder.btn.setText(SettingsList[i].mTitle)
            setVholder.btn.setCompoundDrawablesWithIntrinsicBounds(SettingsList[i].mIcon, 0, 0, 0)

            setVholder.btn.setOnClickListener {
                this@SettingsAdapter.onItemClick(setVholder.adapterPosition)
            }

        } else if (setVholder is SettingViewHolder2) {
            setVholder.btn.setText(SettingsList[i].mTitle)
            setVholder.btn.setCompoundDrawablesWithIntrinsicBounds(SettingsList[i].mIcon, 0, 0, 0)
        }
    }

    private fun getConstantCode(int: Int): Int {
        when (int) {
            0 -> {
                return Constants.INTENT_VAL_OPEN_TERMSN
            }
            1 -> {
                return Constants.INTENT_VAL_OPEN_PRIVCY_POL
            }
            4 -> {
                return Constants.INTENT_VAL_OPEN_ABOUTUS
            }


        }

        return int

    }

    private fun openInfoActivity(intenT_VAL_OPEN_TERMSN: Int) {
        when (intenT_VAL_OPEN_TERMSN) {
            Constants.INTENT_VAL_OPEN_TERMSN,
            Constants.INTENT_VAL_OPEN_PRIVCY_POL,
            Constants.INTENT_VAL_OPEN_ABOUTUS -> {
                val intent = Intent(mContext, TermsnCondnActivity::class.java)
                intent.putExtra(Constants.INTENT_OPEN_ACTION, intenT_VAL_OPEN_TERMSN)
                mContext.startActivity(intent)
            }

            7 -> {
                val intent = Intent(mContext, ChangePasswordActivity::class.java)
                intent.putExtra(Constants.INTENT_KEY_CHANGEPASS, Constants.INTENT_VAL_CHNG_PASS)
                mContext.startActivity(intent)
            }

            8 -> {
                logout()
            }
        }

    }

    override fun getItemCount(): Int {
        return SettingsList.size
    }

    override fun getItemViewType(position: Int): Int {
        return SettingsList[position].mType

    }

    class SettingViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val btn: CFButton

        init {
            btn = itemView.findViewById(R.id.btn)
//            v.setOnClickListener(this)
        }
    }

    class SettingViewHolder2(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val btn: CFButton
        val switch: SwitchCompat

        init {
            btn = itemView.findViewById(R.id.btn)
            switch = itemView.findViewById(R.id.switchw)
//            v.setOnClickListener(this)
        }
    }

}



