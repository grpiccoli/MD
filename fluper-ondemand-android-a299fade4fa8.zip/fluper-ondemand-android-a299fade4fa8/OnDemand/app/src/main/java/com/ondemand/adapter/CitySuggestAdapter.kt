package com.ondemand.adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.ondemand.R

class CitySuggestAdapter : RecyclerView.Adapter<CitySuggestAdapter.ServiceProvViewHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ServiceProvViewHolder {
        return ServiceProvViewHolder(
            LayoutInflater.from(viewGroup.context).inflate(
                R.layout.city_suggest_item_layout,
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(aDepViewHolder: ServiceProvViewHolder, i: Int) {

    }

    override fun getItemCount(): Int {
        return 8
    }

    class ServiceProvViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        override fun onClick(v: View?) {

            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        }

        init {
//            v.setOnClickListener(this)
        }

    }

}



