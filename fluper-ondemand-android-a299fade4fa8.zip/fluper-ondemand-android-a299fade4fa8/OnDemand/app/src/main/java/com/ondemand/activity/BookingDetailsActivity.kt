package com.ondemand.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.ondemand.R
import com.ondemand.customview.CFButton
import com.ondemand.utils.Constants
import com.ondemand.utils.Utils
import kotlinx.android.synthetic.main.activity_booking_details.*
import kotlinx.android.synthetic.main.toolbar.*

class BookingDetailsActivity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.back_btn -> {
                val intent = Intent(this, MapsHomeActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK

                startActivity(intent)
                finish()
            }

            R.id.btn_reschedule -> {
                val intent = Intent(this, SetTimeSlotActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT

                startActivity(intent)
                finish()
            }

            R.id.cancel_booking -> {
                val alert = Utils.showDialog(this, R.layout.dialog_alert_cancel_book)

                alert.findViewById<CFButton>(R.id.btn_yes)?.setOnClickListener{
                    val intent = Intent(this, MapsHomeActivity::class.java)

                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                    intent.putExtra(Constants.INTENT_KEY_ACTION, Constants.INTENT_VAL_CANC_APPNT)

                    startActivity(intent)
                    finish()
                }

                alert.findViewById<CFButton>(R.id.btn_no)?.setOnClickListener {

                    alert.dismiss()
                }

            }
            R.id.btn_proceed -> {
                val intent = Intent(this, MapsHomeActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK

                startActivity(intent)
                finish()
            }

        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_booking_details)
        setListener()

        getIntentAction()

    }

    private fun getIntentAction() {
        intent?.extras?.let {
            when (it.getInt(Constants.INTENT_KEY_ACTION)){

                Constants.INTENT_RESCHEDULE_APPOINT -> {
                    val alertd = Utils.showDialog(this@BookingDetailsActivity,
                        R.layout.dialog_alert_reschedule)

                    alertd.setCancelable(false)
                    alertd.findViewById<CFButton>(R.id.btn_no)?.setOnClickListener {
                        alertd.dismiss()
                    }
                    alertd.findViewById<CFButton>(R.id.btn_yes)?.setOnClickListener {
                        alertd.dismiss()

                        //open next dialog
                        val alertd1 = Utils.showDialog(this@BookingDetailsActivity,
                            R.layout.dialog_alert_change_time)

                        alertd1.setCancelable(false)
                        alertd1.findViewById<CFButton>(R.id.btn_change_time_today)?.setOnClickListener {
                            alertd1.dismiss()
                            val intent = Intent(this@BookingDetailsActivity, SetTimeSlotActivity::class.java)
                            intent.putExtra(Constants.INTENT_KEY_SETTIMESLOT, Constants.INTENT_VAL_BOOKDETLS)

                            startActivity(intent)
//                            startActivity(Intent(this@BookingDetailsActivity, SetTimeSlotActivity::class.java))
                        }
                        alertd1.findViewById<CFButton>(R.id.btn_different_day)?.setOnClickListener {
                            alertd1.dismiss()

                            val intent = Intent(this@BookingDetailsActivity, SetTimeSlotActivity::class.java)
                            intent.putExtra(Constants.INTENT_KEY_SETTIMESLOT, Constants.INTENT_VAL_BOOKDETLS)

                            startActivity(intent)
                        }
                    }
                }

                else ->{

                }

            }

        }

    }

    private fun setListener() {

        back_btn.setOnClickListener(this)
        btn_reschedule.setOnClickListener(this)
        cancel_booking.setOnClickListener(this)
        btn_proceed.setOnClickListener(this)
    }
}
