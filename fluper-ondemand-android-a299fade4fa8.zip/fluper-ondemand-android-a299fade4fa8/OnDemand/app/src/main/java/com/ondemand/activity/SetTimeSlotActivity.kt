package com.ondemand.activity

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import android.widget.ArrayAdapter
import com.ondemand.R
import com.ondemand.adapter.ServiceProvAdapter
import com.ondemand.utils.Constants
import kotlinx.android.synthetic.main.activity_set_time_slot.*

class SetTimeSlotActivity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(v: View?) {
        when (v?.id) {

            R.id.back_btn -> {
                onBackPressed()
            }

            R.id.btn_proceed -> {
                startActivity(Intent(this, ConfirmBookingActivity::class.java))
            }

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_time_slot)

        initUi()
        setListener()

        getIntentAction()

    }

    private fun getIntentAction() {
        intent?.extras?.let {
            when (it.getInt(Constants.INTENT_KEY_SETTIMESLOT)) {
                Constants.INTENT_VAL_BOOKDETLS -> {
                    hideListViews(false)

                }
                Constants.INTENT_VAL_SERVICEPROV -> {
                    hideListViews(true)

                }
                else -> {
                    // do nothing
                }
            }
        }

    }

    fun hideListViews(boolean: Boolean) {
        if (boolean) {
            recyclerview_docs.visibility = View.GONE
            relativeLayout2.visibility = View.VISIBLE
        } else {
            recyclerview_docs.visibility = View.VISIBLE
            relativeLayout2.visibility = View.GONE
        }
    }

    private fun initUi() {

        recyclerview_docs.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        recyclerview_docs.adapter = ServiceProvAdapter(this)

        val list = resources.getStringArray(R.array.entries)
        appCompatSpinner.adapter = ArrayAdapter<String>(this, R.layout.textview_resource, list)
    }

    private fun setListener() {
        back_btn.setOnClickListener(this)
        btn_proceed.setOnClickListener(this)
    }

}
