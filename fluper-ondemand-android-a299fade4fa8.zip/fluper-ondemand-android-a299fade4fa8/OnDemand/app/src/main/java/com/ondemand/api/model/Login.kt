package com.ondemand.api.model

import android.os.Parcel
import android.os.Parcelable

class Login() : Parcelable {
    //{
    //    "response": {
    //        "location": {
    //            "type": "Point",
    //            "coordinates": [
    //                77,
    //                28
    //            ],
    //            "default": []
    //        },
    //        "name": "",
    //        "rutNumber": "45436345662437",
    //        "mobile": "354343474406645",
    //        "password": "81dc9bdb52d04dc20036dbd8313ed055",
    //        "countryCode": "54",
    //        "medicalInsurance": "334er3543",
    //        "email": "su134020@gmail.com",
    //        "deviceType": 1,
    //        "deviceToken": "13234547fvfdd",
    //        "access_token": "b41602d976507cbce71cd9886daaca4d",
    //        "profileImage": "",
    //        "isBlocked": 0,
    //        "isVerified": 0,
    //        "latitude": 28,
    //        "longitude": 77,
    //        "isProfileCreated": 0,
    //        "socialType": 0,
    //        "socialId": "",
    //        "_id": "5ce3c4636c1bac2ffcaa0483",
    //        "createdAt": "2019-05-21T09:26:59.560Z",
    //        "updatedAt": "2019-05-21T09:26:59.560Z"
    //    }
    //}

    var name :String? = ""
    var rutNumber :String? = ""
    var mobile :String? = ""
    var password :String? = ""
    var countryCode :String? = ""
    var medicalInsurance :String? = ""
    var email :String? = ""
    var deviceType :String? = ""
    var deviceToken :String? = ""
    var access_token :String? = ""
    var profileImage :String? = ""
    var isBlocked :String? = ""
    var isVerified :String? = ""
    var latitude :String? = ""
    var longitude :String? = ""
    var isProfileCreated :String? = ""
    var socialType :String? = ""
    var socialId :String? = ""
    var _id :String? = ""
    var createdAt :String? = ""
    var updatedAt :String? = ""

    constructor(parcel: Parcel) : this() {
        name = parcel.readString()
        rutNumber = parcel.readString()
        mobile = parcel.readString()
        password = parcel.readString()
        countryCode = parcel.readString()
        medicalInsurance = parcel.readString()
        email = parcel.readString()
        deviceType = parcel.readString()
        deviceToken = parcel.readString()
        access_token = parcel.readString()
        profileImage = parcel.readString()
        isBlocked = parcel.readString()
        isVerified = parcel.readString()
        latitude = parcel.readString()
        longitude = parcel.readString()
        isProfileCreated = parcel.readString()
        socialType = parcel.readString()
        socialId = parcel.readString()
        _id = parcel.readString()
        createdAt = parcel.readString()
        updatedAt = parcel.readString()
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(name)
        parcel.writeString(rutNumber)
        parcel.writeString(mobile)
        parcel.writeString(password)
        parcel.writeString(countryCode)
        parcel.writeString(medicalInsurance)
        parcel.writeString(email)
        parcel.writeString(deviceType)
        parcel.writeString(deviceToken)
        parcel.writeString(access_token)
        parcel.writeString(profileImage)
        parcel.writeString(isBlocked)
        parcel.writeString(isVerified)
        parcel.writeString(latitude)
        parcel.writeString(longitude)
        parcel.writeString(isProfileCreated)
        parcel.writeString(socialType)
        parcel.writeString(socialId)
        parcel.writeString(_id)
        parcel.writeString(createdAt)
        parcel.writeString(updatedAt)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Login> {
        override fun createFromParcel(parcel: Parcel): Login {
            return Login(parcel)
        }

        override fun newArray(size: Int): Array<Login?> {
            return arrayOfNulls(size)
        }
    }


}