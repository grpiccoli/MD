package com.ondemand.adapter

import android.content.Context
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.ondemand.R
import com.ondemand.activity.TermsnCondnActivity
import com.ondemand.utils.Constants

class HelpQuestAdapter(context: Context) : RecyclerView.Adapter<HelpQuestAdapter.ServiceProvViewHolder>() {

    private val mContext : Context

    init{
        mContext = context
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ServiceProvViewHolder {
        when( getItemViewType(i)){
            0 -> {
                return ServiceProvViewHolder(
                    LayoutInflater.from(viewGroup.context).inflate(
                        R.layout.rv_header_layout_item,
                        viewGroup,
                        false
                    )
                )
            }
            else -> {
                return ServiceProvViewHolder(
                    LayoutInflater.from(viewGroup.context).inflate(
                        R.layout.need_help_query_item_layout,
                        viewGroup,
                        false
                    )
                )
            }
        }

    }

    override fun onBindViewHolder(aDepViewHolder: ServiceProvViewHolder, i: Int) {
        when(getItemViewType(i)){
            1 -> {
                aDepViewHolder.itemView.setOnClickListener{
                    val intent = Intent(mContext, TermsnCondnActivity::class.java)
                    intent.putExtra(Constants.INTENT_OPEN_ACTION, Constants.INTENT_VAL_OPEN_NEEDHELP)
                    mContext.startActivity(intent)
                }
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        when (position % 4) {
            0 -> {
                return 0
            }
            else -> {
                return 1
            }
        }

    }

    override fun getItemCount(): Int {
        return 15
    }

    class ServiceProvViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        override fun onClick(v: View?) {

            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        }

        init {
//            v.setOnClickListener(this)
        }

    }

}



