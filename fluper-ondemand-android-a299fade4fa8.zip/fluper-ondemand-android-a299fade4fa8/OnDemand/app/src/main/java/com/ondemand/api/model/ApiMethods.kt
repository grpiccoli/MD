package com.ondemand.api.model

import android.content.Context
import android.util.Log
import com.ondemand.api.Const
import com.ondemand.storage.PreferenceHelper
import com.ondemand.storage.PreferenceHelper.get

object ApiMethods {
    fun getProfileImageURL(context: Context) : String{
        return Const.BASE_URL + PreferenceHelper.customPrefs(context)[Const.PROFILE_IMG_KEY, ""]
    }
}