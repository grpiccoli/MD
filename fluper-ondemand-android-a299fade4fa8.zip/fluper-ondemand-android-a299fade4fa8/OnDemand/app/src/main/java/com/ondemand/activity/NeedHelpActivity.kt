package com.ondemand.activity

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.ondemand.R
import com.ondemand.adapter.HelpQuestAdapter
import kotlinx.android.synthetic.main.activity_need_help.*
import kotlinx.android.synthetic.main.toolbar_with_btn_end.*

class NeedHelpActivity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.back_btn -> {
                onBackPressed()
            }
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_need_help)

        initRecyclerView()

        setListener()

    }

    private fun initRecyclerView() {

        val llManager1 = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)

        recyclerview1.layoutManager = llManager1

        recyclerview1.adapter = HelpQuestAdapter(this)

    }

    private fun setListener() {
        back_btn.setOnClickListener(this)

    }

}
