package com.ondemand.utils;

public abstract class BaseResponse {
}
