package com.ondemand.api

class Const {
    companion object {
        const val COMMUNE_KEY = "commune"
        const val SEX_KEY = "sex"
        const val BASE_URL = "http://3.17.201.231:3005"
        const val FORGOT_PASSWORD = "/user/forgetPassword"

        const val VERIFYOTP = "/user/verify"
        const val RESETPASSWORD = "/user/resetPassword"
        const val RUT_VERIFY = "/user/verifyRut"
        const val VAL_INSURANCE = "/user/validateInsurance"
        const val GET_INSURANCE = "/user/getInsuranceList"
        const val VAL_PHONE = "/user/validatePhone"
        const val RUT_DETAIL = "/user/getRutDetails"
        const val SIGNUP_KEY = "/user/signUp"
        const val SIGNIN_KEY = "/user/login"
        const val LOGOUT = "/user/logout"
        const val EDIT_PROFILE = "/user/editProfile"
        const val CHANGE_PASSWORD = "/user/changePassword"
        const val OTP_BY_MAIL = "1"


        const val OTP_BY_SMS = "2"
        const val OTP_BY_CALL = "3"
        const val MOBILE_KEY = "mobile"

        const val EMAIL_KEY = "email"
        const val COUNTRYCODE_KEY = "countrycode"
        const val T_MOBILE_KEY = "temp_mobile"

        const val T_EMAIL_KEY = "temp_email"
        const val T_COUNTRYCODE_KEY = "temp_countrycode"
        const val ACCESSTOKEN_KEY = "accesstoken"

        const val PASSWORD_KEY = "password"
        const val RUT_NO_KEY = "rut_num"
        const val ADDRESS_KEY = "address"
        const val MED_INS_KEY = "med_insur"
        const val PROFILE_IMG_KEY = "profileImage"
        const val FIRST_NAME_KEY = "first_name"
        const val LAST_NAME_KEY = "last_name"


    }
}