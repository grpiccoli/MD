package com.ondemand.adapter

import android.content.Context
import android.content.Intent
import android.support.v4.content.ContextCompat.startActivity
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.ondemand.R
import com.ondemand.activity.BookingDetailsActivity
import com.ondemand.customview.CFButton
import com.ondemand.utils.Constants

class MyBookingAdapter(context : Context) : RecyclerView.Adapter<MyBookingAdapter.MyBookingVH>() {

    private var listItem: MutableList<Int> = mutableListOf(1, 2, 2, 1, 3, 1, 3)
    private var listTitles: MutableList<String> =
        mutableListOf("Ongoing Booking", "Booking Cancelation", "Past Bookings")

    private val mContext : Context

    init {
        mContext = context
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): MyBookingVH {
        when (viewType) {
            1 -> {
                return MyBookingVH(
                    LayoutInflater.from(viewGroup.context).inflate(
                        R.layout.rv_header_layout_item,
                        viewGroup,
                        false
                    )
                )
            }
            2 -> {
                return MyBookingVH(
                    LayoutInflater.from(viewGroup.context).inflate(
                        R.layout.ongbooking_layout_item,
                        viewGroup,
                        false
                    )
                )
            }
            3 -> {
                return MyBookingVH(
                    LayoutInflater.from(viewGroup.context).inflate(
                        R.layout.conf_booking_layout_item,
                        viewGroup,
                        false
                    )
                )
            }
            else -> {
                return MyBookingVH(
                    LayoutInflater.from(viewGroup.context).inflate(
                        R.layout.rv_header_layout_item,
                        viewGroup,
                        false
                    )
                )
            }
        }

    }

    override fun onBindViewHolder(mbHolder: MyBookingVH, i: Int) {
        when (getItemViewType(i)){
            1 -> {
                (mbHolder.itemView as TextView)?.setText(listTitles[i % 3])
            }
            2 -> {

                mbHolder.itemView.findViewById<CFButton>(R.id.btn_reschedule)?.setOnClickListener {
                    val intent = Intent(mContext, BookingDetailsActivity::class.java)

                    intent.putExtra(Constants.INTENT_KEY_ACTION, Constants.INTENT_RESCHEDULE_APPOINT)

                    mContext.startActivity(intent)
                    (mContext as AppCompatActivity).finish()
                }

                mbHolder.itemView.findViewById<CFButton>(R.id.btn_cancel)?.setOnClickListener {

                }

            }
            3 -> {
                mbHolder.itemView.findViewById<ImageView>(R.id.img_confirm)?.visibility = View.INVISIBLE
                mbHolder
            }
        }
    }

    override fun getItemViewType(position: Int): Int {
        Log.d("getItemViewType", ""+listItem[position])
        when (listItem[position]) {
            1 -> {
                return 1
            }
            2 -> {
                return 2
            }
            3 -> {
                return 3
            }
        }

        return 1
    }

    override fun getItemCount(): Int {
        return listItem.size
    }

    class MyBookingVH(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        override fun onClick(v: View?) {

            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        }

        init {
//            v.setOnClickListener(this)
        }

    }

}



