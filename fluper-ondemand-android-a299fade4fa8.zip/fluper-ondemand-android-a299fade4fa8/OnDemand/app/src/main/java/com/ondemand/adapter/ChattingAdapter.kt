package com.ondemand.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.ondemand.R

class ChattingAdapter(context: Context) : RecyclerView.Adapter<ChattingAdapter.ChatTextItemVH>() {

    private val mContext: Context

    init {
        mContext = context
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): ChatTextItemVH {
        return ChatTextItemVH(
            LayoutInflater.from(viewGroup.context).inflate(
                R.layout.chat_text_item_layout,
                viewGroup,
                false
            )
        )

    }

    override fun onBindViewHolder(mbHolder: ChatTextItemVH, i: Int) {

    }

    override fun getItemCount(): Int {
        return 1
    }

    class ChatTextItemVH(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        override fun onClick(v: View?) {

            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        }

        init {
//            v.setOnClickListener(this)
        }

    }

}



