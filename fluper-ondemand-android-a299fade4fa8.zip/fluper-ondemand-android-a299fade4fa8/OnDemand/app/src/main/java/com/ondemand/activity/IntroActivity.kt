package com.ondemand.activity

import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.support.v4.view.PagerAdapter
import android.support.v4.view.ViewPager
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.TextView
import com.ondemand.R
import com.ondemand.RunOnce
import com.tbuonomo.viewpagerdotsindicator.DotsIndicator
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.intro_screen_3.*

class IntroActivity : AppCompatActivity() {

    private var introViewPager: ViewPager? = null
    private var introViewPagerAdapter: IntroScreenViewPagerAdapter? = null
    //    private var introBullets: Array<TextView>? = null
//    private var introBulletsLayout: LinearLayout? = null
    private var introSliderLayouts: IntArray? = null
//    private var btnSkip: Button? = null

//    var btnNext: Button? = null

    var currentItem: Int = -1

    private var timer = object : CountDownTimer(4000, 1000) {
        override fun onTick(millisUntilFinished: Long) {
            Log.d("mili", ""+millisUntilFinished)

            introSliderLayouts?.let {
                if (currentItem < it.size) {
                    currentItem = currentItem + 1

                    introViewPager?.setCurrentItem(currentItem)
                }
            }

        }

        override fun onFinish() {
            val intent = Intent(this@IntroActivity, SignInActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK

            startActivity(intent)
            finish()
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = layoutInflater.inflate(R.layout.activity_main, null)
        setContentView(layout)

        introViewPager = layout.intro_view_pager
//        introBulletsLayout = layout.intro_bullets
//        btnSkip = layout.btn_skip
//        btnNext = layout.btn_next

        //Get the intro slides
        introSliderLayouts = intArrayOf(
            R.layout.intro_screen_1,
            R.layout.intro_screen_2,
            R.layout.intro_screen_3
        )
        // adding bottom introBullets
//        makeIIntroBullets(0)

        introViewPagerAdapter = IntroScreenViewPagerAdapter()
        introViewPager!!.adapter = introViewPagerAdapter
        introViewPager!!.addOnPageChangeListener(introViewPagerListener)



//        (btnSkip as View?)!!.setOnClickListener { applicationStartup() }
        /*(btnNext as View?)!!.setOnClickListener {
            // checking for last page
            // if last page home screen will be launched
            val current = getItem(+1)
            if (current < introSliderLayouts!!.size) {
                // move to next screen
                introViewPager!!.currentItem = current
            } else {
                applicationStartup()
            }
        }*/

        // making notification bar transparent
        SetTransperantStatusBar()
        val dotsIndicator = findViewById<DotsIndicator>(R.id.dots_indicator)
        dotsIndicator.setViewPager(introViewPager)

        timer.start()
    }

//    private fun makeIIntroBullets(currentPage: Int) {
//        var arraySize = introSliderLayouts!!.size
//
//        introBullets = Array<TextView>(arraySize) { textboxInit() }
//
//        val colorsActive = resources.getIntArray(R.array.array_intro_bullet_active)
//        val colorsInactive = resources.getIntArray(R.array.array_intro_bullet_inactive)
//
////        introBulletsLayout!!.removeAllViews()
//
//        for (i in 0 until introBullets!!.size) {
//            introBullets!![i] = TextView(this)
//            introBullets!![i].text = Html.fromHtml("&#9679;")
//            introBullets!![i].setTextSize(30F)
//            introBullets!![i].setTextColor(colorsInactive[currentPage])
////            introBulletsLayout!!.addView(introBullets!![i])
//        }
//
//        if (introBullets!!.size > 0)
//            introBullets!![currentPage].setTextColor(colorsActive[currentPage])
//
//    }

    private fun textboxInit(): TextView {
        return TextView(applicationContext)

    }

    private fun getItem(i: Int): Int {
        return introViewPager!!.getCurrentItem() + i

    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUI()
    }

    private fun hideSystemUI() {
        // Enables regular immersive mode.
        // For "lean back" mode, remove SYSTEM_UI_FLAG_IMMERSIVE.
        // Or for "sticky immersive," replace it with SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        window.decorView.systemUiVisibility = (
//                View.SYSTEM_UI_FLAG_IMMERSIVE
/*                // Set the content to appear under the system bars so that the
                // content doesn't resize when the system bars hide and show.
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN*/
                // Hide the nav bar and status bar
//                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                View.SYSTEM_UI_FLAG_FULLSCREEN)

    }

    private var introViewPagerListener: ViewPager.OnPageChangeListener = object : ViewPager.OnPageChangeListener {
        override fun onPageSelected(position: Int) {
//            makeIIntroBullets(position)

            /*Based on the page position change the button text*/
//            if (position == introSliderLayouts!!.size - 1) {
//                btn_next!!.setOnClickListener {
//                    val intent = Intent(this@IntroActivity, SignInActivity::class.java)
//                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
//
//                    startActivity(intent)
//                    finish()
//                }
//        }
             /*else {
                btnNext!!.setText(getString(R.string.next_button_title))
                btnSkip!!.setVisibility(View.VISIBLE)

            }*/

        }

        override fun onPageScrolled(arg0: Int, arg1: Float, arg2: Int) {
            //Do nothing for now
        }

        override fun onPageScrollStateChanged(arg0: Int) {
            //Do nothing for now
        }
    }

    private fun SetTransperantStatusBar() {

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val window = window
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
            window.statusBarColor = Color.TRANSPARENT
        }

    }

    inner class IntroScreenViewPagerAdapter : PagerAdapter() {

        override fun instantiateItem(container: ViewGroup, position: Int): Any {

            val layoutInflater: LayoutInflater = LayoutInflater.from(applicationContext)
            val view = layoutInflater.inflate(introSliderLayouts!![position], container, false)
            view.setOnClickListener{
                timer.cancel()

                val intent = Intent(this@IntroActivity, SignInActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK

                startActivity(intent)
                finish()
            }
            container.addView(view)
            return view

        }

        override fun getCount(): Int {
            return introSliderLayouts!!.size

        }

        override fun isViewFromObject(view: View, obj: Any): Boolean {
            return view === obj

        }

        override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
            val view = `object` as View
            container.removeView(view)

        }

    }

}

