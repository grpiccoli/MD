package com.ondemand.adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.ondemand.R

class MyPaymentAdapter : RecyclerView.Adapter<MyPaymentAdapter.ADepViewHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ADepViewHolder {
        return ADepViewHolder(
            LayoutInflater.from(viewGroup.context).inflate(
                R.layout.pymnt_hist_layout_item,
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(aDepViewHolder: ADepViewHolder, i: Int) {

    }

    override fun getItemCount(): Int {
        return 4
    }

    class ADepViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), View.OnClickListener {
        override fun onClick(v: View?) {
            TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
        }

//        private var view: View = v
//        private var photo: Photo? = null


        init {
//            v.setOnClickListener(this)
        }
    }

}



