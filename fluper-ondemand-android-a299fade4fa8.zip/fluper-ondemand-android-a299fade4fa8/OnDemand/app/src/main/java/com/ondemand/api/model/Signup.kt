package com.ondemand.api.model

class Signup {
    //{
    //    "response": {
    //        "location": {
    //            "type": "Point",
    //            "coordinates": [
    //                77,
    //                28
    //            ],
    //            "default": []
    //        },
    //        "name": "",
    //        "rutNumber": "454363437",
    //        "mobile": "354343445",
    //        "password": "81dc9bdb52d04dc20036dbd8313ed055",
    //        "countryCode": "54",
    //        "medicalInsurance": "3323543",
    //        "email": "su13020@gmail.com",
    //        "deviceType": 1,
    //        "deviceToken": "13234547f2vfdd",
    //        "access_token": "4f61fa76590bf8ebcc3e130b430a9f14",
    //        "profileImage": "",
    //        "isBlocked": 0,
    //        "isVerified": 0,
    //        "latitude": 28,
    //        "longitude": 77,
    //        "isProfileCreated": 0,
    //        "socialType": 0,
    //        "socialId": "",
    //        "_id": "5ce3f4b4e3bc663066679137",
    //        "createdAt": "2019-05-21T12:53:08.392Z",
    //        "updatedAt": "2019-05-21T12:53:08.392Z"
    //    }
    //}

    var name :String? = ""
    var rutNumber :String? = ""
    var mobile :String? = ""
    var password :String? = ""
    var countryCode :String? = ""
    var medicalInsurance :String? = ""
    var email :String? = ""
    var deviceType :String? = ""
    var deviceToken :String? = ""
    var access_token :String? = ""
    var profileImage :String? = ""
    var isBlocked :String? = ""
    var isVerified :String? = ""
    var latitude :String? = ""
    var longitude :String? = ""
    var isProfileCreated :String? = ""
    var socialType :String? = ""
    var socialId :String? = ""
    var _id :String? = ""
    var createdAt :String? = ""
    var updatedAt :String? = ""


}