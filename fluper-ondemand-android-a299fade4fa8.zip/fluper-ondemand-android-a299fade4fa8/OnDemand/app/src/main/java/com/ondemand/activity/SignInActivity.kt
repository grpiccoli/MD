package com.ondemand.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.widget.EditText
import com.google.gson.Gson
import com.ondemand.api.ApiClient
import com.ondemand.api.ApiInterface
import com.ondemand.api.Const
import com.ondemand.api.model.CommonResp
import com.ondemand.api.model.RUTDetails
import com.ondemand.api.model.RUTVerify
import com.ondemand.api.model.ResponseSignin
import com.ondemand.storage.PreferenceHelper
import com.ondemand.storage.PreferenceHelper.set
import com.ondemand.utils.*
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_sign_in.*


class SignInActivity : AppCompatActivity(), View.OnClickListener {
    private var isRutValid = false

    override fun onClick(v: View?) {
        when (v?.id) {

            com.ondemand.R.id.sign_up_btn -> {
                startActivityForResult(
                    Intent(this@SignInActivity, SignUpActivity::class.java),
                    Constants.ACTIVITY_RESULT_ALREADY_EXIST
                )
            }

            com.ondemand.R.id.sign_in_btn -> {
                validateInput()
            }

            com.ondemand.R.id.skip_sign_in -> {

                val intent = Intent(this@SignInActivity, MapsHomeActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK

                startActivity(intent)

                finish()
            }

            com.ondemand.R.id.forgot_password -> {
                PreferenceHelper.clearTempOTPVals(this)
                startActivity(Intent(this@SignInActivity, ForgotPasswordActivity::class.java))
            }

        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.ondemand.R.layout.activity_sign_in)

        setListeners()

    }

    private fun setListeners() {

        sign_in_btn.setOnClickListener(this)
        sign_up_btn.setOnClickListener(this)
        skip_sign_in.setOnClickListener(this)
        forgot_password.setOnClickListener(this)

        input_rut.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                val text = (v as EditText).text.toString()
                text.let {
                    if (!it.isEmpty()) {
                        validateRUT(text, service)

                    }
                }
            }
        }

        input_rut.addTextChangedListener(RUTTextFormatter(input_rut))

    }

    val service = ApiClient.client.create(ApiInterface::class.java)


    private fun validateInput() {
        val rutEdt = findViewById(com.ondemand.R.id.input_rut) as EditText
        val passEdt = findViewById(com.ondemand.R.id.input_password) as EditText

        val rutText: String = rutEdt.text.toString()/*.replace(".", "")*/
        val passText: String = passEdt.text.toString()

        var isValid: Boolean = true

        //check if the EditText have values or not
        if (rutText.trim().isEmpty()) {
            isValid = false

            rutEdt.setError("Please enter the RUT code.")
        } else if (rutText.length < 8 /*&& rutText.length != 10*/) {
            isValid = false
            rutEdt.setError("Please enter the valid RUT code.")
        }

        if (passText.trim().isEmpty()) {
            isValid = false

            passEdt.setError("Please enter the password.")
        } else if (!(passText.length >= 8 && passText.length <= 16)) {
            isValid = false
            passEdt.setError("Please enter the valid password.")
        }

        if (isValid && isRutValid) {
            //do the login
            sign_in_btn.isEnabled = false
            val ser = service.signIn(
                rut = input_rut.text.toString(),
                latitude = "28",
                longitude = "77",
                password = input_password.text.toString(),
                devToken = DeviceInfo.getDeviceUUID(),
                devType = "1"
            )

                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { onSuccess(it, input_password.text.toString()) },
                    { onFailure(it) }
                )
//
        } else {
            //some error occurred invalid input

        }
    }

    fun validateRUT(rutText: String, service: ApiInterface) {
        val ser = service.verifyRUT(
            rut = rutText
        )
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { onSuccessValidateRUT(it) },
                { onFailureRUT(it) }
            )
    }

    private fun onFailureRUT(it: Throwable?) {
        isRutValid = false
        sign_in_btn.isEnabled = true
        Utils.showToast(this, "The RUT number entered is not valid")
        input_rut.setError("Invalid RUT number")
    }

    private fun onSuccessValidateRUT(it: RUTVerify?) {
        isRutValid = true
        if (it?.message.equals("true")) {
            input_rut.setText(it?.response?.formattedRutNo)
            Log.d("verifyrut", "")

        }
    }


    fun getRutDetail(rutText: String) {
        val ser = service.getRUTDetail(
            rutNumber = rutText
        )

            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { onSuccessDET(it) },
                { onFailureRUT(it) }
            )
    }

    private fun onSuccessDET(it: RUTDetails?) {

        val prefs = PreferenceHelper.customPrefs(applicationContext)

        prefs[Const.FIRST_NAME_KEY] = it?.response?.name.toString()
        prefs[Const.ADDRESS_KEY] = it?.response?.address.toString()
        prefs[Const.SEX_KEY] = it?.response?.sex.toString()
        prefs[Const.COMMUNE_KEY] = it?.response?.comune.toString()

    }


    private fun onSuccess(it: ResponseSignin?, password: String) {
        sign_in_btn.isEnabled = true
        getRutDetail(it?.response?.rutNumber!!)
        val prefs = PreferenceHelper.customPrefs(applicationContext)


        prefs[Const.RUT_NO_KEY] = it?.response?.rutNumber.toString()
        prefs[Const.ACCESSTOKEN_KEY] = it?.response?.access_token.toString()
        prefs[Const.COUNTRYCODE_KEY] = it?.response?.countryCode.toString()
        prefs[Const.MOBILE_KEY] = it?.response?.mobile.toString()
        prefs[Const.EMAIL_KEY] = it?.response?.email.toString()
        prefs[Const.MED_INS_KEY] = it?.response?.medicalInsurance.toString()
        prefs[Const.PROFILE_IMG_KEY] = it?.response?.profileImage.toString()
        prefs[Const.PASSWORD_KEY] = password

        Utils.showToast(this@SignInActivity, it?.message.toString())

        //success
        startActivity(Intent(this@SignInActivity, MapsHomeActivity::class.java))

        finish()

        Log.d("Success", it.toString())

    }

    private fun onFailure(it: Throwable?) {
        sign_in_btn.isEnabled = true

        ErrorUtil.handlerGeneralError(this, it!!, true)
//        ErrorHandlingClass.errorHandlingException(this, it)
//        if (it?.message.equals("HTTP 403 Forbidden"))
//        Utils.showToast(this@SignInActivity, "Invalid credentials")
//        it?.cause
        Log.d("Error", it.toString())

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == Constants.ACTIVITY_RESULT_ALREADY_EXIST &&
            resultCode == Activity.RESULT_OK
        ) {

        }
    }

}
