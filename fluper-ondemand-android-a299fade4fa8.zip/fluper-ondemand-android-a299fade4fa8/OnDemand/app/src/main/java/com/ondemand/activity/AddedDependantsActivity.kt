package com.ondemand.activity

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.ondemand.R
import com.ondemand.adapter.AddedDependantAdapter
import com.ondemand.utils.Constants
import kotlinx.android.synthetic.main.activity_added_dependants.*
import kotlinx.android.synthetic.main.toolbar.*

class AddedDependantsActivity : AppCompatActivity(), View.OnClickListener {

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.continue_btn -> {
                val intent = Intent(this@AddedDependantsActivity, MapsHomeActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK

                startActivity(intent)

                finish()
            }
            R.id.back_btn -> {
                onBackPressed()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_added_dependants)

        initView()

        getIntentData()

        setListener()
    }

    private fun getIntentData() {
        intent?.extras?.let {
            when (it.getInt(Constants.INTENT_KEY_ADDED_DEP, -1)) {

                Constants.INTENT_VAL_PROF_ADDED_DEP -> {
                    continue_btn.visibility = View.GONE
                }
                Constants.INTENT_VAL_SIGNUP_ADDED_DEP -> {

                }
            }
        }

    }

    private fun initView() {
        toolbar_text.setText(getString(R.string.title_added_dep))

        val adapter = AddedDependantAdapter()
        recyclerview.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerview.adapter = adapter
    }

    private fun setListener() {
        continue_btn.setOnClickListener(this)

        back_btn.setOnClickListener(this)
    }

}
