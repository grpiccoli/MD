package com.ondemand.fragment


import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import com.ondemand.R
import com.ondemand.adapter.ServiceProvAdapter
import kotlinx.android.synthetic.main.content_maps_home.*
import kotlinx.android.synthetic.main.fragment_service.*
import android.widget.AbsListView
import android.support.v7.widget.RecyclerView



// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 *
 */
class ServiceProviderFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment

        return inflater.inflate(R.layout.fragment_service, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        activity!!.btn_view_as_list.visibility = View.VISIBLE
        activity!!.btn_view_as_list.text = "VIEW AS MAP"

        rv_serv_provider.layoutManager = LinearLayoutManager(context, LinearLayoutManager.VERTICAL, false)
        rv_serv_provider.adapter = ServiceProvAdapter(activity!!)

        rv_serv_provider.addOnScrollListener(object : RecyclerView.OnScrollListener() {

            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                if (dy > 0) {
                    // Scrolling up
                    activity!!.btn_view_as_list.visibility = View.GONE

                } else {
                    // Scrolling down
                    activity!!.btn_view_as_list.visibility = View.VISIBLE
                }
            }

            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)

                if (newState == AbsListView.OnScrollListener.SCROLL_STATE_FLING) {
                    // Do something
                } else if (newState == AbsListView.OnScrollListener.SCROLL_STATE_TOUCH_SCROLL) {
                    // Do something
                } else {
                    // Do something
                }
            }
        })
    }





}
