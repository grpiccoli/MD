package com.ondemand.api.model

class Otp {
    //{
    //    "response": {
    //        "location": {
    //            "type": "Point",
    //            "coordinates": [
    //                77,
    //                28
    //            ],
    //            "default": []
    //        },
    //        "name": "",
    //        "rutNumber": "45436345662437",
    //        "mobile": "354343474406645",
    //        "password": "81dc9bdb52d04dc20036dbd8313ed055",
    //        "countryCode": "54",
    //        "medicalInsurance": "334er3543",
    //        "email": "su134020@gmail.com",
    //        "deviceType": 1,
    //        "deviceToken": "13234547fvfdd",
    //        "access_token": "b41602d976507cbce71cd9886daaca4d",
    //        "profileImage": "",
    //        "isBlocked": 0,
    //        "isVerified": 0,
    //        "latitude": 28,
    //        "longitude": 77,
    //        "isProfileCreated": 0,
    //        "socialType": 0,
    //        "socialId": "",
    //        "_id": "5ce3c4636c1bac2ffcaa0483",
    //        "createdAt": "2019-05-21T09:26:59.560Z",
//            "verificationCode": "123456",
    //        "updatedAt": "2019-05-21T09:26:59.560Z"
    //    }
    //}

    var name :String? = ""
    var rutNumber :String? = ""
    var mobile :String? = ""
    var password :String? = ""
    var countryCode :String? = ""
    var medicalInsurance :String? = ""
    var email :String? = ""
    var deviceType :String? = ""
    var deviceToken :String? = ""
    var access_token :String? = ""
    var profileImage :String? = ""
    var isBlocked :String? = ""
    var isVerified :String? = ""
    var latitude :String? = ""
    var longitude :String? = ""
    var isProfileCreated :String? = ""
    var socialType :String? = ""
    var socialId :String? = ""
    var _id :String? = ""
    var createdAt :String? = ""
    var updatedAt :String? = ""
    var verificationCode : String? = ""
    var location : Location? = null

}