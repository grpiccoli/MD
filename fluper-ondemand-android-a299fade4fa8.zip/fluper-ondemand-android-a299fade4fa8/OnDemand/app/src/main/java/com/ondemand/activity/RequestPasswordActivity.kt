package com.ondemand.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import com.ondemand.R
import kotlinx.android.synthetic.main.activity_request_password.*
import kotlinx.android.synthetic.main.toolbar.*

class RequestPasswordActivity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(v: View?) {
        when(v?.id) {
            R.id.back_btn -> {
                onBackPressed()
            }

            R.id.btnRecoverPass -> {
                val intent= Intent(this, SignUpActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT

                startActivity(intent)
                finish()
            }
        }
    }

    val textWatcher = object : TextWatcher {
        var prevL = 0

        override fun afterTextChanged(s: Editable?) {

        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            prevL = edtEmailAddress.text!!.length
        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            val length = s!!.length

            if ((prevL < length) && (length == 2 || length == 6 || length == 10)) {
                if (start == 1) {
                    edtEmailAddress.setText(s.toString() + ".")
                    edtEmailAddress.setSelection(length + 1)
                } else

                    if (start == 5) {
                        edtEmailAddress.setText(s.toString() + ".")

                        edtEmailAddress.setSelection(length + 1)
                    } else

                        if (start == 9) {
                            edtEmailAddress.setText(s.toString() + "-")

                            edtEmailAddress.setSelection(length + 1)
                        }
            }

        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_request_password)

        initUi()
        setListener()

    }

    private fun initUi() {
        toolbar_text.text = "Request Your Password"
//        edtEmailAddress.addTextChangedListener(textWatcher)

    }

    private fun setListener() {

        back_btn.setOnClickListener(this)
        btnRecoverPass.setOnClickListener(this)

    }

}
