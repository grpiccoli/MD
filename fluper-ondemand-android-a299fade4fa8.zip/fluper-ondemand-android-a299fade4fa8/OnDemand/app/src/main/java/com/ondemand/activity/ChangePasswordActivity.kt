package com.ondemand.activity

import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View

import com.ondemand.R
import com.ondemand.api.ApiClient
import com.ondemand.api.ApiInterface
import com.ondemand.api.Const
import com.ondemand.api.model.CommonResp
import com.ondemand.storage.PreferenceHelper
import com.ondemand.storage.PreferenceHelper.get
import com.ondemand.storage.PreferenceHelper.set
import com.ondemand.utils.Utils

import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_change_password.*
import kotlinx.android.synthetic.main.toolbar.*

class ChangePasswordActivity : AppCompatActivity(), View.OnClickListener {
    override fun onClick(v: View?) {
        when (v?.id) {

            R.id.back_btn -> {

                onBackPressed()
            }

            R.id.btn_chng_pass -> {
                validateInput()
            }
        }

    }

    val service = ApiClient.client.create(ApiInterface::class.java)

    private fun validateInput() {
        val prefs = PreferenceHelper.customPrefs(applicationContext)

        var isValid = true

        val currentPassEntered = edt_current_pass.text.toString()
        val currentPassSaved: String? = prefs[Const.PASSWORD_KEY]

        val newPassword = edt_new_pass.text.toString()
        val newRePassword = edt_reenter_pass.text.toString()

        if (currentPassEntered.isEmpty()) {
            isValid = false
            edt_current_pass.setError("Please enter the current password.")

        } else if (!currentPassEntered.equals(currentPassSaved)) {
            isValid = false
            edt_current_pass.setError("Please enter the correct old password.")

        }


        if (newPassword.isEmpty()) {
            isValid = false
            edt_new_pass.setError("Please enter the new password.")

        } else if (newPassword.contains(" ")) {
            isValid = false
            edt_new_pass.setError("Please enter the valid password. Whitespaces not allowed.")

        } else if (!(newPassword.length >= 8 && newPassword.length <= 16)) {
            isValid = false
            edt_new_pass.setError("Password length must be in range 8-16.")

        } else if (newPassword.equals(currentPassEntered)){
            isValid = false
            edt_new_pass.setError("New password can not be same as old password.")
        }

        if (newRePassword.isEmpty()) {
            isValid = false
            edt_reenter_pass.setError("Please enter the new password.")

        } else if (newRePassword.contains(" ")) {
            isValid = false
            edt_reenter_pass.setError("Please enter the valid password. Whitespaces not allowed.")

        } else if (!newPassword.equals(newRePassword)) {
            isValid = false
            edt_reenter_pass.setError("New Password and Reenter New Password not matching")

        }


        if (isValid) {
            // call change password api
            changePassword(currentPassEntered, newPassword, prefs)
        }

    }

    fun changePassword(password: String, newPass: String, prefs: SharedPreferences) {
        val ser = service.changePassword(
            prefs[Const.ACCESSTOKEN_KEY],
            password,
            newPass
        )

            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { onSuccessPasswordChange(it, newPass, prefs) },
                { onFailure(it) }
            )
    }

    private fun onFailure(it: Throwable?) {


    }

    private fun onSuccessPasswordChange(
        it: CommonResp?,
        newPass: String,
        prefs: SharedPreferences
    ) {
        prefs[Const.PASSWORD_KEY] = newPass
        showDialog()

    }

    private fun showDialog() {
        val alert = Utils.showDialog(
            this, R.layout.pass_recover_dialog_layout/*, DialogInterface.OnDismissListener {
            it.dismiss()
            val intent = Intent(this@GeneratePasswordActivity, SignInActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
            startActivity(intent)
        }*/
        )

        alert.setCancelable(false)
        alert.findViewById<View>(R.id.alert_dialog)?.setOnClickListener {
            alert.dismiss()

//            val intent = Intent(this@ChangePasswordActivity, SignInActivity::class.java)
//            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
//            startActivity(intent)

            finish()

        }

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)

        initUI()

        setListener()
    }

    private fun initUI() {
        toolbar_text.setText("Change Password")

    }

    private fun setListener() {

        back_btn.setOnClickListener(this)
        btn_chng_pass.setOnClickListener(this)
    }
}
