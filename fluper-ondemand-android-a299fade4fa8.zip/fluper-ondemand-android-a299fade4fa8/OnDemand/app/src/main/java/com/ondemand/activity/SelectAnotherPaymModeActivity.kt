package com.ondemand.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.ondemand.R
import com.ondemand.utils.Constants
import kotlinx.android.synthetic.main.selected_payment_mode_layout.*
import kotlinx.android.synthetic.main.toolbar.*
import kotlinx.android.synthetic.main.toolbar.toolbar_text

class SelectAnotherPaymModeActivity : AppCompatActivity(), View.OnClickListener {
    private var code: Int = 0

    override fun onClick(v: View?) {

        when(v?.id){
            R.id.mob_app -> {
                val  intent = Intent(this, AppointmentBookedActivity::class.java)
                intent.putExtra(Constants.INTENT_KEY_CHAT_PAY, code)

                startActivity(intent)
                finish()
            }
            R.id.cancel_payment -> {
                val intent = Intent(this, MapsHomeActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK

                startActivity(intent)
            }
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.selected_payment_mode_layout)

        initUi()

        setListener()

        getIntentAction()

    }

    private fun getIntentAction() {
        intent?.extras?.let {
            code = it.getInt(Constants.INTENT_KEY_CHAT_PAY)
        }

    }


    private fun setListener() {
        mob_app.setOnClickListener(this)
        cancel_payment.setOnClickListener(this)

    }

    private fun initUi() {

        toolbar_text.text = "Select Payment Mode"
    }
}
