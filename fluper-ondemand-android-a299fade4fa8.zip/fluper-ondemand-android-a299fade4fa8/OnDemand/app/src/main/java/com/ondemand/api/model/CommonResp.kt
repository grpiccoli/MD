package com.ondemand.api.model

data class CommonResp(val message: String?,
                      val response: Any?) {
//    {
//        "message": "true",
//        "response": true
//    }

}