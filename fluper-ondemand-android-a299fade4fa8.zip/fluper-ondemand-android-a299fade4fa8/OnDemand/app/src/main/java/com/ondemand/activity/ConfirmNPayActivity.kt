package com.ondemand.activity

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.ondemand.R
import com.ondemand.adapter.DoctorOnlineAdapter
import com.ondemand.utils.Constants
import kotlinx.android.synthetic.main.activity_confirm_npay.*
import kotlinx.android.synthetic.main.toolbar.*

class ConfirmNPayActivity : AppCompatActivity(), View.OnClickListener {
    private var code : Int = 0

    override fun onClick(v: View?) {
        when (v?.id) {

            R.id.back_btn -> {
                onBackPressed()
            }

            R.id.btn_conf_pay -> {
                val intent = Intent( this, SelectPaymentModeActivity::class.java)
                intent.putExtra(Constants.INTENT_KEY_CHAT_PAY, code)
                startActivity(intent)
            }
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_confirm_npay)

        initUi()
        setListener()

        getIntentAction()
    }

    private fun getIntentAction() {
        intent?.extras?.let {
            code = it.getInt(Constants.INTENT_KEY_CHAT_PAY)
        }

    }

    private fun initUi() {
        toolbar_text.text = "Confirm and Pay"

        recview.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recview.adapter = DoctorOnlineAdapter(this)

    }

    private fun setListener() {
        back_btn.setOnClickListener(this)
        btn_conf_pay.setOnClickListener(this)
    }
}
