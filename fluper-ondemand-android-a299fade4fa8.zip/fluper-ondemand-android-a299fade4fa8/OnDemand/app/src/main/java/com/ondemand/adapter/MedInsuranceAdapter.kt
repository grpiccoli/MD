package com.ondemand.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.RadioGroup
import com.ondemand.R
import com.ondemand.customview.CFRadioButton
import com.ondemand.interfaces.ItemClickPositionListener
import com.ondemand.model.InsuranceContent

class MedInsuranceAdapter(context: Context, _array: MutableList<InsuranceContent>, listener: ItemClickPositionListener) :
    RecyclerView.Adapter<MedInsVH>() {
    var rg: RadioGroup? = null

    var listItems: MutableList<InsuranceContent> = mutableListOf()
    var mContext: Context? = null
    var mListener: ItemClickPositionListener? = null
    var listState: MutableList<Boolean> = mutableListOf()

    init {
        mContext = context
        listItems = _array

        mListener = listener
        rg = RadioGroup(mContext)
        for (i in 0..listItems.size - 1) {
            listState.add(i, false)
        }
    }

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): MedInsVH {
        val inflater = LayoutInflater.from(p0.context)

        return MedInsVH(inflater, p0)

    }

    override fun getItemCount(): Int {

        return listItems.size

    }

    override fun onBindViewHolder(vh: MedInsVH, p1: Int) {

        vh.selectedRB?.setText("" + listItems.get(p1).siteName)
//        vh.selectedRB?.setCompoundDrawablesWithIntrinsicBounds(
//            null, null,
//            listItems.get(p1).inc_icon, null
//        )

//        rg?.addView(vh.selectedRB)
        if (listItems.size > listState.size) {

            listState.add(p1, false)

        } else if (listState[p1]) {

            vh.selectedRB?.isChecked = true

        } else {

            vh.selectedRB?.isChecked = false
        }

        vh.selectedRB?.setOnClickListener {

            for (i in 0..listItems.size - 1) {
                if (i==p1) {
                    listState[p1] = false
                }
            }
            notifyDataSetChanged()

            mListener?.onItemClick(p1)
        }

    }

}

class MedInsVH(view: LayoutInflater, parent: ViewGroup) :
    RecyclerView.ViewHolder(view.inflate(R.layout.dialog_list_single_choice_item, parent, false)) {

    var selectedRB: CFRadioButton? = null

    //
    init {
        selectedRB = itemView.findViewById(R.id.select_btn)

    }

}