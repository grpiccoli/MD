package com.ondemand.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.view.View
import com.ondemand.R
import com.ondemand.adapter.MyBookingAdapter
import kotlinx.android.synthetic.main.activity_my_booking.*
import kotlinx.android.synthetic.main.toolbar.*

class MyBookingActivity : AppCompatActivity(), View.OnClickListener {

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.back_btn -> {
                onBackPressed()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_booking)
        initUi()

        setListener()
    }

    private fun initUi() {
        toolbar_text.setText("My Bookings")
        recyclerview_ong_bk.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        recyclerview_ong_bk.adapter = MyBookingAdapter(this)
    }

    private fun setListener() {
        back_btn.setOnClickListener(this)

    }
}
