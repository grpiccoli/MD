package com.ondemand.utils;

import android.app.Activity;
import android.content.Context;
import android.widget.Toast;
import com.jakewharton.retrofit2.adapter.rxjava2.HttpException;
import org.json.JSONObject;

import java.net.ConnectException;
import java.net.SocketTimeoutException;

public class ErrorHandlingClass {


    public static void errorHandlingException(Context context , Throwable it){

        it.printStackTrace();

        if (it instanceof HttpException) {
            try {
                if (((HttpException) it).code() ==400) {
                    JSONObject jObjError = new JSONObject(((HttpException)it).response().errorBody().string());
                    Toast.makeText(context, jObjError.getString("message"), Toast.LENGTH_LONG).show();
                } else if (((HttpException) it).code() == 401) {
                    Toast.makeText(context, "Please login again", Toast.LENGTH_SHORT).show();
                 //   context.startActivity(new Intent(context, LoginActivity.class));
                    ((Activity) context).finishAffinity();

                } else if (((HttpException) it).code() == 403) {
                    Toast.makeText(context, "Invalid credentials entered", Toast.LENGTH_SHORT).show();
    
                }
            }catch (Exception e){
                e.printStackTrace();
                Toast.makeText(context,e.toString(), Toast.LENGTH_SHORT).show();
            }
        }else if (it instanceof ConnectException) {
            Toast.makeText(context,"Please check your internet connection", Toast.LENGTH_SHORT).show();
        }else if (it instanceof SocketTimeoutException) {
            Toast.makeText(context,"Please check your internet connection", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context,"Something wents wrong.", Toast.LENGTH_SHORT).show();

        }
    }
}


