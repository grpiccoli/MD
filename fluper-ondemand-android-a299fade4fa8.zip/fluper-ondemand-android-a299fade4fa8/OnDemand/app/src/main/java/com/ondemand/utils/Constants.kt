package com.ondemand.utils

class Constants {
    companion object {
        const val INTENT_KEY_OTP_BY = "action_otpby"
        const val INTENT_VAL_CHNG_PASS = 40
        const val INTENT_KEY_CHANGEPASS = "act_change_pass"
        const val INTENT_VAL_CHATDOC = 44
        const val INTENT_VAL_OTP_BY_SMS = 88
        const val INTENT_VAL_OTP_BY_CALL = 89
        const val INTENT_KEY_CHAT_PAY = "action_chat_pay"
        const val INTENT_KEY_SETTIMESLOT = "action_settimeslot"
        const val INTENT_VAL_BOOKDETLS = 33
        const val INTENT_VAL_SERVICEPROV = 34
        val INTENT_VAL_OPEN_TERMSN = 17
        val INTENT_VAL_OPEN_PRIVCY_POL = 18
        val INTENT_VAL_OPEN_ABOUTUS = 19
        const val INTENT_VAL_OPEN_NEEDHELP = 20
        const val INTENT_OPEN_ACTION = "action_open"
        const val INTENT_RESCHEDULE_APPOINT = 404
        const val INTENT_VAL_CANC_APPNT = 401
        const val INTENT_KEY_ACTION = "data_action"
        const val INTENT_KEY_ADDED_DEP = "data_extra"
        const val INTENT_VAL_PROF_ADDED_DEP = 201
        const val INTENT_VAL_SIGNUP_ADDED_DEP = 202
        const val ACTIVITY_RESULT_ALREADY_EXIST = 203
    }
}