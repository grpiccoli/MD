package com.ondemand.activity

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.support.design.widget.Snackbar
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.telephony.PhoneNumberFormattingTextWatcher
import android.text.TextUtils
import android.util.Log
import android.view.View
import com.bumptech.glide.Glide
import com.ondemand.R
import com.ondemand.api.ApiClient
import com.ondemand.api.ApiInterface
import com.ondemand.api.Const
import com.ondemand.api.model.ApiMethods
import com.ondemand.api.model.CommonResp
import com.ondemand.api.model.ResponseSignUp
import com.ondemand.storage.PreferenceHelper
import com.ondemand.storage.PreferenceHelper.get
import com.ondemand.storage.PreferenceHelper.set
import com.ondemand.storage.StorageUtils
import com.ondemand.storage.StorageUtils.Companion.getImageFilePath
import com.ondemand.storage.StorageUtils.Companion.getImageUri
import com.ondemand.storage.StorageUtils.Companion.getRealPathFromURI
import com.ondemand.utils.Constants
import com.ondemand.utils.ImageUtils.compressImageFile
import com.ondemand.utils.Utils
import io.michaelrocks.libphonenumber.android.NumberParseException
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil
import io.michaelrocks.libphonenumber.android.Phonenumber
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_profile_edit.*
import kotlinx.android.synthetic.main.toolbar.*
import kotlinx.android.synthetic.main.toolbar.back_btn
import okhttp3.MediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.*

class ProfileEditActivity : AppCompatActivity(), View.OnClickListener {
    val service = ApiClient.client.create(ApiInterface::class.java)

    var phoneUtil: PhoneNumberUtil? = null
    lateinit var prefs: SharedPreferences


    override fun onClick(v: View?) {

        when (v?.id) {
            R.id.back_btn -> {
                onBackPressed()
            }
            R.id.tv_view_dep -> {
                val intent = Intent(this@ProfileEditActivity, AddedDependantsActivity::class.java)

                intent.putExtra(Constants.INTENT_KEY_ADDED_DEP, Constants.INTENT_VAL_PROF_ADDED_DEP)

                startActivity(intent)
            }
            R.id.btnUpdateSave -> {
                getInput()
            }

            R.id.img_btn_edit -> {
                if (checkPermission())
                    StorageUtils.captureImage(this)
            }
        }

    }

    private fun getInput() {

        btnUpdateSave.isEnabled = false
        var isValid = true

        var email = edt_input_email.text.toString()

        val com_mob_no = edt_input_mobile.text.toString().replace(" ", "")
        var number: Phonenumber.PhoneNumber? = null

        var mob_no = ""
        var cc_code = ""

        try {
            number = phoneUtil?.parse(com_mob_no, "")

        } catch (R: NumberParseException) {
            if (R.errorType == NumberParseException.ErrorType.INVALID_COUNTRY_CODE) {
                Utils.showToast(this, "Invalid country code entered!")
                edt_input_mobile.setError("Enter a valid country code with + sign")
            } else {
                Utils.showToast(this, "Invalid mobile number entered")
                edt_input_mobile.setError("Enter a valid mobile number ")
            }
        }

        number?.let {
            mob_no = it.nationalNumber.toString()

            cc_code = it.countryCode.toString()

        }

        if (email.isEmpty()) {
            email = prefs[Const.EMAIL_KEY, ""]!!
        }

        if (!Utils.isValidEmail(email)) {
            isValid = false
            edt_input_email.setError("Please enter the valid email address!")
        }

        if (cc_code.isEmpty()) {
            cc_code = prefs[Const.COUNTRYCODE_KEY, ""]!!
        }

        if (mob_no.isEmpty()) {
            mob_no = prefs[Const.MOBILE_KEY, ""]!!
        }

        if (isValid) {
            editProfile(email, cc_code, mob_no)
        }

    }

    fun editProfile(email: String, countrycode: String, mobile: String) {
        val ser = service.editProfile(
            prefs[Const.ACCESSTOKEN_KEY],
            getMultiPartyObjects(email),
            getMultiPartyObjects(countrycode),
            getMultiPartyObjects(mobile),
            getProfileImage()
        )

            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { onSuccessProfileChange(it, prefs) },
                { onFailure(it) }
            )
    }

    private fun onFailure(it: Throwable?) {
        btnUpdateSave.isEnabled = true
        Log.d("Error", it?.message)
    }

    private fun onSuccessProfileChange(it: ResponseSignUp?, prefs: SharedPreferences) {
        btnUpdateSave.isEnabled = true
        Utils.showToast(this, "Profile updated successfully.")

        prefs[Const.PROFILE_IMG_KEY] = it?.response!!.profileImage
        prefs[Const.EMAIL_KEY] = it.response!!.email
        prefs[Const.MOBILE_KEY] = it.response!!.mobile
        prefs[Const.COUNTRYCODE_KEY] = it.response!!.countryCode

    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_edit)

        initUi()
        setListener()
    }

    private fun initUi() {
        toolbar_text.setText("Profile")
        phoneUtil = PhoneNumberUtil.createInstance(applicationContext)
        prefs = PreferenceHelper.customPrefs(applicationContext)
        var comNumber: Phonenumber.PhoneNumber? = null
        try {

            comNumber = phoneUtil!!.parse(
                "+" +
                        prefs[Const.COUNTRYCODE_KEY, ""] + prefs[Const.MOBILE_KEY, ""],
                ""
            )
        } catch (e: NumberParseException) {
            when (e.errorType) {
                NumberParseException.ErrorType.NOT_A_NUMBER -> {

                }

                NumberParseException.ErrorType.INVALID_COUNTRY_CODE -> {

                }
            }
        }

        try {

            if (!isFinishing) {
                Glide.with(applicationContext)
                    .asBitmap()
                    .load(ApiMethods.getProfileImageURL(applicationContext))
                    .placeholder(R.drawable.place_holder) // Remote URL of image.
                    .into(iv_profile)
            }

        } catch (e: UnsupportedOperationException) {
            Log.e("Error", e.message)

        }

        try {


            val com_name = prefs[Const.FIRST_NAME_KEY, ""]!!.split(" ")

            if (com_name.size == 1) {
                edt_input_first_name.setText(com_name[0])

            }

            if (com_name.size > 2) {
                edt_input_first_name.setText(com_name[0] +" "+ com_name[1])
                for (e in 2..com_name.size - 1) {
                    edt_input_last_name.setText(com_name[e]+" ")
                }
            }
            edt_input_email.setText(prefs[Const.EMAIL_KEY, ""])
            edt_input_rut.setText(prefs[Const.RUT_NO_KEY, ""])

            edt_input_mobile.setText(phoneUtil!!.format(comNumber, PhoneNumberUtil.PhoneNumberFormat.INTERNATIONAL))

            //  edt_input_med_ins.text = prefs[Const.MED_INS_KEY]
            edt_input_med_inspass.setText(prefs[Const.MED_INS_KEY, ""])
            edt_input_med_ins.setText(prefs[Const.MED_INS_KEY, ""])

        } catch (e: Exception) {
            Log.d("Error", e.stackTrace.toString())

        }

    }

    private fun setListener() {
        back_btn.setOnClickListener(this)
        tv_view_dep.setOnClickListener(this)
        btnUpdateSave.setOnClickListener(this)
        img_btn_edit.setOnClickListener(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            edt_input_mobile.addTextChangedListener(
                //            RUTTextFormatter(input_mob_number)

                PhoneNumberFormattingTextWatcher("+56")
            )
        } else {
            edt_input_mobile.addTextChangedListener(
                //            RUTTextFormatter(input_mob_number)

                PhoneNumberFormattingTextWatcher()
            )
        }
    }


    private fun getMultiPartyObjects(strVal: String): RequestBody {
        return RequestBody.create(
            MediaType.parse("multipart/form-data"), strVal
        )
    }

    private var imageuri: Uri? = null
    private var compressedImgPath: String? = null


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == StorageUtils.GALLERY_CONSTANT) {
            if (resultCode == AppCompatActivity.RESULT_OK) {
                imageuri = data?.data

                val compressed: File? = compressImageFile(this, imageuri!!)
                compressedImgPath = compressed?.path

                if (!isFinishing)
                    Glide.with(this)
                        .load(imageuri).placeholder(R.drawable.place_holder) // Remote URL of image.
                        .into(iv_profile)

//                img_avtarprofile.setImageURI(null)
//                img_avtarprofile.setImageURI(imageuri)
//
//                img_avtarprofile.postInvalidate()
            }
        } else if (requestCode == StorageUtils.CAMERA_CONSTANT) {
            if (resultCode == AppCompatActivity.RESULT_OK) {
                val bitmap: Bitmap = data!!.extras!!.get("data") as Bitmap
                imageuri = getImageUri(this, bitmap)

                val compressed: File? = compressImageFile(this, imageuri!!)
                compressedImgPath = compressed?.path

//                img_avtarprofile.setImageURI(null)
//                img_avtarprofile.setImageURI(imageuri)
//
//                img_avtarprofile.postInvalidate()

                if (!isFinishing)
                    Glide.with(this)
                        .load(imageuri).placeholder(R.drawable.place_holder) // Remote URL of image.
                        .into(iv_profile)

            }
        }
    }

    fun checkPermission(): Boolean {


        if (((ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) + ContextCompat
                .checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) + ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ))
                    != PackageManager.PERMISSION_GRANTED)
        ) {
            if ((ActivityCompat.shouldShowRequestPermissionRationale(
                    this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                ) ||
                        ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA))
            ) {
                System.out.println(" -----------------  if part ")
                Snackbar.make(
                    this.findViewById(android.R.id.content),
                    "Please Grant Permissions",
                    Snackbar.LENGTH_INDEFINITE
                ).setActionTextColor(Color.WHITE).setAction(
                    "ENABLE"
                ) {
                    ActivityCompat.requestPermissions(
                        this,
                        arrayOf(
                            Manifest.permission
                                .WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA,
                            Manifest.permission.READ_EXTERNAL_STORAGE
                        ),
                        StorageUtils.REQUEST_PERMISSION_SETTING
                    )
                }.show()
                return false
            } else {

                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(
                        Manifest.permission
                            .WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.CAMERA
                    ),
                    StorageUtils.REQUEST_PERMISSION_SETTING
                )
                return false
            }
        } else {

            return true
        }
    }

    private fun getProfileImage(): MultipartBody.Part? {

//            val path = CommonFunctions().getPath(this, imageuri!!)
//            val file = File(path)
        if (!compressedImgPath.isNullOrEmpty()) {
            val file = File(compressedImgPath)
            val requestFile = RequestBody.create(MediaType.parse("image/*"), file)
            // imageuri = null
            return MultipartBody.Part.createFormData(
                "profileImage", file.name,
                requestFile
            )
        } else {
            return null
        }

    }

}
