package com.ondemand.activity

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import com.ondemand.R
import com.ondemand.utils.Constants
import kotlinx.android.synthetic.main.activity_summary.*

class SummaryActivity : AppCompatActivity(), View.OnClickListener {
    private var code: Int = 0

    override fun onClick(v: View?) {
        when (v?.id) {

            R.id.back_btn -> {
                onBackPressed()
            }

            R.id.btnRecoverPass -> {
                val intent = Intent( this, SelectAnotherPaymModeActivity::class.java)
                intent.putExtra(Constants.INTENT_KEY_CHAT_PAY, code)

                startActivity(intent)
            }

        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_summary)

        setListener()

        getIntentAction()
    }

    private fun getIntentAction() {
        intent?.extras?.let {
            code = it.getInt(Constants.INTENT_KEY_CHAT_PAY)
        }

    }

    private fun setListener() {
        back_btn.setOnClickListener(this)
        btnRecoverPass.setOnClickListener(this)
    }
}
