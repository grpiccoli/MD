package com.ondemand.activity

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.telephony.PhoneNumberFormattingTextWatcher
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ProgressBar
import com.ondemand.R
import com.ondemand.adapter.MedInsuranceAdapter
import com.ondemand.api.ApiClient
import com.ondemand.api.ApiInterface
import com.ondemand.api.Const.Companion.ACCESSTOKEN_KEY
import com.ondemand.api.Const.Companion.COUNTRYCODE_KEY
import com.ondemand.api.Const.Companion.EMAIL_KEY
import com.ondemand.api.Const.Companion.RUT_NO_KEY
import com.ondemand.api.model.CommonResp
import com.ondemand.api.model.MedInsuranceList
import com.ondemand.api.model.RUTVerify
import com.ondemand.api.model.ResponseSignUp
import com.ondemand.customview.CFButton
import com.ondemand.customview.CFTextView
import com.ondemand.interfaces.ItemClickPositionListener
import com.ondemand.model.InsuranceContent
import com.ondemand.storage.PreferenceHelper.customPrefs
import com.ondemand.storage.PreferenceHelper.set
import com.ondemand.utils.*
import io.michaelrocks.libphonenumber.android.AsYouTypeFormatter
import io.michaelrocks.libphonenumber.android.NumberParseException
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil
import io.michaelrocks.libphonenumber.android.Phonenumber
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_sign_up.*
import com.ondemand.api.Const.Companion.MOBILE_KEY as MOBILE_KEY1

class SignUpActivity : AppCompatActivity(), View.OnClickListener {

    var alertD: AlertDialog? = null
    val service = ApiClient.client.create(ApiInterface::class.java)
    private var isRutValid = false
    private var isMedInsValid = false

    var phoneUtil: PhoneNumberUtil? = null
    var asYouTypeFormatter: AsYouTypeFormatter? = null


    override fun onClick(v: View?) {
        when (v?.id) {

            R.id.back_btn -> {
                onBackPressed()

            }

            R.id.skip_sign_in -> {
                val intent = Intent(this@SignUpActivity, MapsHomeActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK

                startActivity(intent)

                finish()
            }

            R.id.sign_up_btn -> {
                validateAndSignUp()

//

            }

            R.id.input_med_insurance -> {
                if (input_rut.text.isNullOrEmpty()) {
                    Utils.showToast(this@SignUpActivity, "Please enter the RUT first!")
                    input_rut.setError("Please enter the RUT first!")
                    return
                }

                alertD = showDialog()

            }

        }

    }

    val mobileNumberWatcher = object : TextWatcher {
        var prevL = 0

        override fun afterTextChanged(s: Editable?) {
        }

        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            prevL = input_rut.text!!.length
        }

        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
            Log.d("onTextChanged", "$s: CharSequence?, $start: Int, $before: Int, $count: Int")

            if (before < count) {
                //user entering text
                input_mob_number.setText(asYouTypeFormatter?.inputDigit(s!!.get(before)))
                input_mob_number.setSelection(input_mob_number.text!!.length)

            } else {
                //user clearing the text
                asYouTypeFormatter?.clear()
                for (a in 0..s!!.length - 1) {
                    asYouTypeFormatter?.inputDigit(s.get(a))

                }
                input_mob_number.setText(asYouTypeFormatter?.inputDigit("".first()))
                input_mob_number.setSelection(input_mob_number.text!!.length)

            }
//
        }
    }

    private fun onFailure(it: Throwable?) {
        sign_up_btn.isEnabled = true

        var cr = ErrorUtil.handlerGeneralError(this, it!!, false)
        cr?.let {
            if ((it as CommonResp).message.equals("User already registered")) {
//                setResult(Activity.RESULT_OK, intent)
//                finish()
                val alert = Utils.showDialog(this, R.layout.dialog_signup_already_exist)
                alert.findViewById<CFButton>(R.id.btn_okay)?.setOnClickListener {

                    val intent: Intent = Intent(this@SignUpActivity, SignInActivity::class.java)
                    intent.putExtra("rut_existing", input_rut.text.toString())

                    intent.flags = Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    startActivity(intent)
                    finish()

                }
            }
        }
//        ErrorHandlingClass.errorHandlingException(this, it)
//        Utils.showToast(this@SignUpActivity, it?.message.toString())
        Log.d("Error", it.toString())

    }


    private fun onSuccess(it: ResponseSignUp?) {
        sign_up_btn.isEnabled = true
        Utils.showToast(this@SignUpActivity, "Successfully signed up")

        //save data
        val prefs = customPrefs(this@SignUpActivity)
        prefs[MOBILE_KEY1] = it?.response?.mobile
        prefs[EMAIL_KEY] = it?.response?.email
        prefs[RUT_NO_KEY] = it?.response?.rutNumber
        prefs[ACCESSTOKEN_KEY] = it?.response?.access_token
        prefs[COUNTRYCODE_KEY] = it?.response?.countryCode

        //open next
        val intent = Intent(this@SignUpActivity, AddedDependantsActivity::class.java)
        intent.putExtra(Constants.INTENT_KEY_ADDED_DEP, Constants.INTENT_VAL_SIGNUP_ADDED_DEP)
//
        startActivity(intent)

        Log.d("Success", it.toString())

    }

    private fun validateAndSignUp() {

        val rutNum = input_rut.text.toString()/*.replace(".", "")*/
        val pass = input_password.text.toString()
        val conf_pass = input_conf_pass.text.toString()
        val med_ins = input_med_insurance.text.toString()

        val com_mob_no = input_mob_number.text.toString().replace(" ", "")
        var number: Phonenumber.PhoneNumber? = null
        var isValid = true

        var mob_no = ""
        var cc_code = ""

        try {
            number = phoneUtil?.parse(com_mob_no, "")

        } catch (R: NumberParseException) {
            if (R.errorType == NumberParseException.ErrorType.INVALID_COUNTRY_CODE) {
                Utils.showToast(this, "Invalid country code entered!")
                input_mob_number.setError("Enter a valid country code with + sign")
            } else {
                Utils.showToast(this, "Invalid mobile number entered")
                input_mob_number.setError("Enter a valid mobile number ")
            }
        }

        number?.let {
            mob_no = it.nationalNumber.toString()

            cc_code = it.countryCode.toString()

        }

        val email_add = input_email_add.text.toString()

        if (rutNum.isEmpty()) {
            isValid = false
            input_rut.setError("RUT number empty")
        } else if (rutNum.length < 9 /*&& rutNum.length != 10*/) {
            isValid = false
            input_rut.setError("RUT number is invalid")
        }

        if (pass.isEmpty()) {
            isValid = false
            input_password.setError("Password empty")
        } else if (!(pass.length >= 8 && pass.length <= 16)) {
            isValid = false
            input_password.setError("Password length must be in range 8-16")
        }

        if (conf_pass.isEmpty()) {
            isValid = false
            input_conf_pass.setError("Confirm Password empty")
        } /*else if (conf_pass.length > 5 && conf_pass.length < 15) {
            isValid = false
            input_conf_pass.setError("Password must be in between 6-14")
        }*/ else if (!conf_pass.equals(pass)) {
            isValid = false
            input_conf_pass.setError("Confirm Password is not matching")

        }

        if (med_ins.isEmpty()) {
            isValid = false
            input_med_insurance.setError("Medical Insurance number empty")
        }

        if (cc_code.isEmpty()) {
            isValid = false
        }

        if (mob_no.isEmpty()) {
            isValid = false
            input_mob_number.setError("Mobile number empty")
        } else if (!(mob_no.length >= 8 && mob_no.length <= 14) && !Utils.isValidPhone(mob_no)) {
            isValid = false
            input_mob_number.setError("Mobile number length must be in range 8-14")
        }

        if (email_add.isEmpty()) {
            isValid = false
            input_email_add.setError("Email address empty")
        } else if (!Utils.isValidEmail(email_add)) {
            isValid = false
            input_email_add.setError("Email address invalid")
        }

        if (!accept_terms_chkbx.isChecked) {
            isValid = false
            Utils.showToast(this, "Please accept the terms and condition")
        }

        if (!isMedInsValid) {
            isValid = false
            Utils.showToast(this, "Please select the medical insurance")
            input_med_insurance.setError("Please select the medical insurance")
        }

        if (isValid && isRutValid) {
            sign_up_btn.isEnabled = false
            val ser = service.signup(
                rut = input_rut.text.toString(),
                medIns = input_med_insurance.text.toString(),
                mobile = mob_no,
                countryc = cc_code,
                email = input_email_add.text.toString(),
                latitude = "28",
                longitude = "77",
                password = input_password.text.toString(),
                devToken = DeviceInfo.getDeviceUUID(),
                devType = "1"
            )

                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { onSuccess(it) },
                    { onFailure(it) }
                )

//            validateRUT(rutNum, service)
        }

    }

    fun validateRUT(rutText: String, service: ApiInterface) {
        val ser = service.verifyRUT(
            rut = rutText
        )

            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                { onSuccessValidateRUT(it) },
                { onFailureRUT(it) }
            )
    }


    private fun onSuccessValidateRUT(it: RUTVerify?) {
        isRutValid = true
        if (it?.message.equals("true")) {
            input_rut.setText(it?.response?.formattedRutNo)
            Log.d("verifyrut", "")

        }

    }

    private fun onFailureRUT(it: Throwable?) {
        isRutValid = false
        sign_up_btn.isEnabled = true
        Utils.showToast(this, "The RUT number entered is not valid")
        input_rut.setError("Invalid RUT number")
    }

    private fun showDialog(): AlertDialog {
        val builderSingle = AlertDialog.Builder(this@SignUpActivity)
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_list_layout, null, false)
        builderSingle.setView(view)

        val recList = view.findViewById<RecyclerView>(R.id.recyclerview)
        val progress = view.findViewById<ProgressBar>(R.id.progress_circular)

        recList.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)


        val array = mutableListOf<InsuranceContent>()
//
//        array.add(InsuranceContent("Particular ", ContextCompat.getDrawable(this, R.drawable.particular)))
//        array.add(InsuranceContent("Fonasa ", ContextCompat.getDrawable(this, R.drawable.fonasa)))
//        array.add(InsuranceContent("Consalud ", ContextCompat.getDrawable(this, R.drawable.consalud)))
//        array.add(InsuranceContent("Cruz Blanca ", ContextCompat.getDrawable(this, R.drawable.cruz)))
//        array.add(InsuranceContent("Nueva Más Vida ", ContextCompat.getDrawable(this, R.drawable.masvida)))
//        array.add(InsuranceContent("Vida Tres ", ContextCompat.getDrawable(this, R.drawable.vidatres)))

        val adapter = MedInsuranceAdapter(this, array, object : ItemClickPositionListener {
            override fun onItemClick(pos: Int) {
//                if (pos == 0 || pos == 1) {
//                    alertD?.dismiss()
//                    return
//                }

                val alert = Utils.showDialog(this@SignUpActivity, R.layout.dialog_enter_med_ins_pass)

                val edt = alert.findViewById<EditText>(R.id.input_password)
                val close = alert.findViewById<ImageButton>(R.id.close_btn)
                val forgot = alert.findViewById<CFTextView>(R.id.forgot_med_ins_pass)

                val selected = array.get(pos).siteName.toString()
                alert.setCancelable(false)

                edt?.setOnEditorActionListener { v, actionId,
                                                 event ->

                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        // Perform action on key press
//                        Toast.makeText(this@SignUpActivity, edt.text, Toast.LENGTH_SHORT).show();
                        val s = service.validateInsurance(
                            input_rut.text.toString(),
                            edt.text.toString(),
                            selected
                        )

                            .subscribeOn(Schedulers.io())
                            .observeOn(AndroidSchedulers.mainThread())
                            .subscribe(
                                {
                                    alert.dismiss()
                                    Utils.showToast(this@SignUpActivity, it.message.toString())
                                    isMedInsValid = true
                                    input_med_insurance.setText(selected)

                                    alertD?.dismiss()
                                },
                                {
                                    isMedInsValid = false
                                    ErrorHandlingClass.errorHandlingException(this@SignUpActivity, it)
                                    onFailure(it)
                                }
                            )

                        true

                    }
                    false
                }

                close?.setOnClickListener {
                    alert.dismiss()

                }

                forgot?.setOnClickListener {
                    alert.dismiss()

                    startActivity(Intent(this@SignUpActivity, RecoverPasswordActivity::class.java))

                }
            }
        })

        recList.adapter = adapter
        val alert = builderSingle.show()

        val s = service.getInsuranceList()
            .subscribeOn(Schedulers.io())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe(
                {
                    progress.visibility = View.GONE
                    array.addAll(it.response)
                    recList.adapter?.notifyItemRangeInserted(0, it.response.size)
                },
                {
                    progress.visibility = View.GONE
                    alert.dismiss()
                    onFailure(it)
                }
            )

        return alert

    }

    fun getInsList(rutText: String, service: ApiInterface) {
//        val ser = service.getInsuranceList()
//
//            .subscribeOn(Schedulers.io())
//            .observeOn(AndroidSchedulers.mainThread())
//            .subscribe(
//                { onSuccessGetList(it) },
//                { onFailureRUT(it) }
//            )
    }

    private fun onSuccessGetList(it: MedInsuranceList?) {

    }


    override fun onPause() {
        super.onPause()
        alertD?.dismiss()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(com.ondemand.R.layout.activity_sign_up)

        initUtils()

        setListener()

    }

    private fun initUtils() {
        phoneUtil = PhoneNumberUtil.createInstance(applicationContext)

    }

    private fun setListener() {

        back_btn.setOnClickListener(this)
        skip_sign_in.setOnClickListener(this)
        sign_up_btn.setOnClickListener(this)
        input_med_insurance.setOnClickListener(this)

        input_rut.addTextChangedListener(RUTTextFormatter(input_rut))

        input_rut.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus) {
                val text = (v as EditText).text.toString()
                text.let {
                    if (!text.isEmpty()) {
                        validateRUT(input_rut.text.toString(), service)
                    }
                }

            }
        }

//        tv_country_code.setOnCountryChangeListener {
//            asYouTypeFormatter = phoneUtil?.getAsYouTypeFormatter(tv_country_code.selectedCountryNameCode)
//        }

//        input_mob_number.addTextChangedListener(PhoneNumberFormattingTextWatcher())
        /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            input_mob_number.addTextChangedListener(
                PhoneNumberFormattingTextWatcher(tv_country_code.selectedCountryNameCode)
            )
        } else {*/
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            input_mob_number.addTextChangedListener(
    //            RUTTextFormatter(input_mob_number)

                PhoneNumberFormattingTextWatcher("+56")
            )
        } else {
            input_mob_number.addTextChangedListener(
                //            RUTTextFormatter(input_mob_number)

                PhoneNumberFormattingTextWatcher()
            )
        }
//        }

//        input_mob_number.setOnFocusChangeListener { v, hasFocus ->
//            if (!hasFocus) {
//                val text = (v as EditText).text.toString()
//                text.let {
//                    if (!it.isEmpty() && it.length > 3) {
//                        service.formatPhoneNo(
//                            countryCode = tv_country_code.selectedCountryCode,
//                            mobile = input_mob_number.text.toString(),
//                            countryCodeName = tv_country_code.defaultCountryNameCode
//                        )
//                            .subscribeOn(Schedulers.io())
//                            .observeOn(AndroidSchedulers.mainThread())
//                            .subscribe(
//                                { onSuccessFormat(it) },
//                                {
//                                    Log.e("Error", it.message)
//                                }
//                            )
//                    }
//                }
//            }
//        }

    }

    private fun onSuccessFormat(it: CommonResp?) {
        input_mob_number.setText(it?.response as String)

    }

}

