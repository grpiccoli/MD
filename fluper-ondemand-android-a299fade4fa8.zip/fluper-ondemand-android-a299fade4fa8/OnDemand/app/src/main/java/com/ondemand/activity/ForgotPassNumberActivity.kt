package com.ondemand.activity

import android.content.Intent
import android.os.Bundle
import android.support.v4.content.ContextCompat
import android.support.v7.app.AppCompatActivity
import android.telephony.PhoneNumberFormattingTextWatcher
import android.util.Log
import android.view.View
import com.ondemand.R
import com.ondemand.api.ApiClient
import com.ondemand.api.ApiInterface
import com.ondemand.api.Const
import com.ondemand.api.model.CommonResp
import com.ondemand.api.model.ResponseOtp
import com.ondemand.storage.PreferenceHelper
import com.ondemand.storage.PreferenceHelper.set
import com.ondemand.utils.Constants
import com.ondemand.utils.ErrorUtil
import com.ondemand.utils.Utils
import io.michaelrocks.libphonenumber.android.NumberParseException
import io.michaelrocks.libphonenumber.android.PhoneNumberUtil
import io.michaelrocks.libphonenumber.android.Phonenumber
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import kotlinx.android.synthetic.main.activity_forgot_pass_number.*

class ForgotPassNumberActivity : AppCompatActivity(), View.OnClickListener {

    var otpType = Const.OTP_BY_SMS
    val service = ApiClient.client.create(ApiInterface::class.java)
    var phoneUtil: PhoneNumberUtil? = null

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_send_otp -> {
                validateNCheck()
            }
            R.id.back_btn -> {
                onBackPressed()
            }
        }
    }

    private fun initUtils() {
        phoneUtil = PhoneNumberUtil.createInstance(applicationContext)

    }

    private fun validateNCheck() {

        val com_mob_no = input_mob_number.text.toString().replace(" ", "")
        var number: Phonenumber.PhoneNumber? = null

        try {
            number = phoneUtil?.parse(com_mob_no, "")

        } catch (R: NumberParseException) {
            if (R.errorType == NumberParseException.ErrorType.INVALID_COUNTRY_CODE) {
                Utils.showToast(this, "Invalid country code entered!")
                input_mob_number.setError("Enter a valid country code with + sign")
            } else {
                Utils.showToast(this, "Invalid mobile number entered")
                input_mob_number.setError("Enter a valid mobile number ")
            }
        }

        var mob = ""
        var code = ""

        number?.let {
            mob = it.nationalNumber.toString()

            code = it.countryCode.toString()

        }


        var isValid = true
        if (code.isEmpty()) {
            isValid = false
        }
        if (mob.isEmpty()) {
            isValid = false
            input_mob_number.setError("Mobile number is empty")
        } else if (!(mob.length >= 8 && mob.length <= 14)) {
            isValid = false
            input_mob_number.setError("Mobile number length must be in range 8-14")
        }

        if (isValid) {
            val prefs = PreferenceHelper.customPrefs(applicationContext)
            prefs[Const.T_MOBILE_KEY] = mob
            prefs[Const.T_COUNTRYCODE_KEY] = code

            btn_send_otp.isEnabled = false
//            when (otpType){
//                Const.OTP_BY_SMS -> {
            val ser = service.forgotPassword(mob, "+$code", "", otpType)

                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(
                    { onSuccess(it) },
                    { onFailure(it) }
                )
//                }
//                Const.OTP_BY_CALL -> {
//                    val ser = service.forgotPassword(mob, code, "", otpType)
//
//                        .subscribeOn(Schedulers.io())
//                        .observeOn(AndroidSchedulers.mainThread())
//                        .subscribe(
//                            { onSuccess(it) },
//                            { onFailure(it) }
//                        )
//                }
//            }


        }
    }

    private fun onFailure(it: Throwable?) {
        btn_send_otp.isEnabled = true


        ErrorUtil.handlerGeneralError(this, it!!, true)
//        ErrorHandlingClass.errorHandlingException(this, it)

        Log.d("Error", it.toString())

    }

    private fun onSuccess(it: ResponseOtp?) {
        btn_send_otp.isEnabled = true

        Utils.showToast(this@ForgotPassNumberActivity, it?.message.toString())

        //open generate pass activity
        val intent = Intent(this, EnterOtpActivity::class.java)
        intent.putExtra(Constants.INTENT_KEY_OTP_BY, otpType)

        startActivity(intent)

        Log.d("Success", it.toString())

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_pass_number)

        initUtils()
        setListener()


        getIntentAction()
        updateUI()
    }

    private fun updateUI() {
        when (otpType) {
            Const.OTP_BY_SMS -> {
                otp_img.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.email))
                text.setText(getString(R.string.otp_on_sms))

            }

            Const.OTP_BY_CALL -> {
                otp_img.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.cellphone))
                text.setText(getString(R.string.otp_on_call))

            }
        }

    }

    private fun getIntentAction() {
        intent?.extras?.let {
            when (it.getInt(Constants.INTENT_KEY_OTP_BY)) {
                Constants.INTENT_VAL_OTP_BY_SMS -> {
                    otpType = Const.OTP_BY_SMS
                }
                Constants.INTENT_VAL_OTP_BY_CALL -> {
                    otpType = Const.OTP_BY_CALL

                }
            }
        }
    }

    private fun setListener() {
        btn_send_otp.setOnClickListener(this)
        back_btn.setOnClickListener(this)

//        input_mob_number.setOnFocusChangeListener { v, hasFocus ->
//            if (!hasFocus){
//                val text = (v as EditText).text.toString()
//                text?.let {
//                    if (!it.isEmpty() && it.length > 3){
//                        service.formatPhoneNo(countryCode = tv_country_code.selectedCountryCode,
//                            mobile = input_mob_number.text.toString(),
//                            countryCodeName = tv_country_code.defaultCountryNameCode)
//                            .subscribeOn(Schedulers.io())
//                            .observeOn(AndroidSchedulers.mainThread())
//                            .subscribe(
//                                { onSuccessFormat(it) },
//                                { }
//                            )
//                    }
//                }
//            }
//
//        }
        /*if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            input_mob_number.addTextChangedListener(
                PhoneNumberFormattingTextWatcher(tv_country_code.selectedCountryNameCode)
            )
        } else {*/
        input_mob_number.addTextChangedListener(
            PhoneNumberFormattingTextWatcher()
        )
//        }


        /*input_mob_number.setOnKeyBoardDismissListener { ctrl, text ->
            text?.let {
                if (!it.isEmpty() && it.length > 3) {
                    service.formatPhoneNo(
                        countryCode = tv_country_code.selectedCountryCode,
                        mobile = input_mob_number.text.toString(),
                        countryCodeName = tv_country_code.defaultCountryNameCode
                    )
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(
                            { onSuccessFormat(it) },
                            { }
                        )
                }
            }
        }*/

    }

    private fun onSuccessFormat(it: CommonResp?) {
        val formatted = it?.response as String
        input_mob_number.setText(formatted)
        input_mob_number.setSelection(formatted!!.length)
        input_mob_number.isSelected = false

    }

}
