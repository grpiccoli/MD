package com.ondemand.adapter

import android.content.Context
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.ondemand.R
import com.ondemand.activity.SetTimeSlotActivity
import com.ondemand.activity.ViewDocProfileActivity
import com.ondemand.utils.Constants
import de.hdodenhof.circleimageview.CircleImageView

class ServiceProvAdapter(context: Context) : RecyclerView.Adapter<ServiceProvAdapter.ServiceProvViewHolder>() {

    val mContext: Context

    init {
        mContext = context
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ServiceProvViewHolder {
        return ServiceProvViewHolder(
            LayoutInflater.from(viewGroup.context).inflate(
                R.layout.service_prov_list_item_layout,
                viewGroup,
                false
            )
        )
    }

    override fun onBindViewHolder(servHolder: ServiceProvViewHolder, i: Int) {


        servHolder.bind(View.OnClickListener {
            when (it) {
                servHolder.btnBookDoc -> {
                    val intent = Intent(mContext, SetTimeSlotActivity::class.java)
                    intent.putExtra(Constants.INTENT_KEY_SETTIMESLOT, Constants.INTENT_VAL_SERVICEPROV)

                    mContext.startActivity(intent)
                }
                servHolder.btnViewProf -> {
                    mContext.startActivity(Intent(mContext, ViewDocProfileActivity::class.java))

                }
            }
        })
    }

    override fun getItemCount(): Int {
        return 3
    }

    class ServiceProvViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val tvDoctorName: TextView
        val tvQualiDet: TextView
        val tvEducDet: TextView
        val tvYearOfExp: TextView
        val tvNextAvail: TextView
        val tvClinicDet: TextView
        val civProfile: CircleImageView
        val tvSpeciality: TextView
        val tvRate1: ImageView
        val tvRate2: ImageView
        val tvRate3: ImageView
        val tvRate4: ImageView
        val tvRate5: ImageView
        val btnViewProf: Button
        val btnBookDoc: Button

        init {

            tvDoctorName = itemView.findViewById(R.id.tvdoctor_name)
            tvQualiDet = itemView.findViewById(R.id.tv_qualific)
            tvEducDet = itemView.findViewById(R.id.tv_education)
            tvYearOfExp = itemView.findViewById(R.id.tv_year_exp)
            tvNextAvail = itemView.findViewById(R.id.tv_next_avail)
            tvClinicDet = itemView.findViewById(R.id.tv_clinic_det)
            civProfile = itemView.findViewById(R.id.civProfile)
            tvSpeciality = itemView.findViewById(R.id.tv_speciality)
            tvRate1 = itemView.findViewById(R.id.iv_star_1)
            tvRate2 = itemView.findViewById(R.id.iv_star_2)
            tvRate3 = itemView.findViewById(R.id.iv_star_3)
            tvRate4 = itemView.findViewById(R.id.iv_star_4)
            tvRate5 = itemView.findViewById(R.id.iv_star_5)
            btnViewProf = itemView.findViewById(R.id.btn_view_doc_prof)
            btnBookDoc = itemView.findViewById(R.id.book_doc)

        }

        fun bind(listener: View.OnClickListener) {
            btnViewProf.setOnClickListener(listener)
            btnBookDoc.setOnClickListener(listener)
        }

    }

}



