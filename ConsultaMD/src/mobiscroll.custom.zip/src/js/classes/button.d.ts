import { FormControl } from './form-control';
import { MbscFormOptions } from './forms';

export class Button extends FormControl {
    constructor(element: any, settings: MbscFormOptions);
}