import { Base, MbscCoreOptions } from '../core/core';

export class ProgressBase<T extends MbscCoreOptions> extends Base<T> { }
