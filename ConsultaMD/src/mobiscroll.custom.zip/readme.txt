This is a commercial Mobiscroll package, licensed to Guillermo Rodriguez <contacto@epicsolutions.cl> with license key 38f0e02d-18f7-45e6-bacf-6b9795b557e2. 

Please refer to the EULA licensing terms (present in the license folder) or https://mobiscroll.com/EULA for more info.